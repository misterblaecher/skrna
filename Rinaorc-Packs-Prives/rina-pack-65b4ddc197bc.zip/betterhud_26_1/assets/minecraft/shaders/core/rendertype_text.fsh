#version 330
#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3
/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif
#ifdef SB_MOJ
#moj_import <minecraft:rinaskyblock_gui_pipeline.glsl>
#else
#include <minecraft:rinaskyblock_gui_pipeline.glsl>
#endif
#if !defined(IS_SEE_THROUGH) && !defined(OIT) && (defined(IS_GUI) || (!defined(IS_GRAYSCALE) && !defined(SB_GUI_PIPELINE)))
#define SB_OURS
#endif
#ifdef SB_MOJ
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
#else
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#endif
uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
SB_LOC(0) in float sphericalVertexDistance;SB_LOC(1) in float cylindricalVertexDistance;
#endif
SB_LOC(2) in vec4 vertexColor;SB_LOC(3) in vec2 texCoord0;
#ifndef OIT_ALPHA_ONLY
SB_LOC(0) out vec4 fragColor;
#endif
#ifdef SB_OURS
SB_LOC(5) flat in float gsOn;
#
SB_LOC(6) in vec2 gsLocal;
#
SB_LOC(7) in vec2 gsCanvas;
#
SB_LOC(8) flat in vec4 gsP0;
#
SB_LOC(9) flat in vec4 gsP1;
#
SB_LOC(10) flat in vec4 gsRect;
#
SB_LOC(11) flat in vec4 gsClip;
#
SB_LOC(12) flat in vec2 gsSz;
#
vec4 gsAt(vec2 p) {
#
if (p.x < 0.0 || p.y < 0.0 || p.x >= gsSz.x || p.y >= gsSz.y) return vec4(0.0);
#
return textureLod(Sampler0, gsRect.xy + (floor(p) + 0.5) * gsRect.zw, 0.0);
#
}
#
float gsHash(vec2 p) {
#
return fract(sin(dot(floor(p), vec2(12.9898, 78.233))) * 43758.5453);
#
}
#
vec4 gsGlow(vec4 m, vec2 p) {
#
vec3 glow = gsP0.rgb;
#
float age = gsP0.a / 20.0;
#
float t = gsP1.z;
#
float h = gsHash(p);
#
int kinds = int(m.b * 255.0 + 0.5);
#
float str = m.a;
#
vec3 c = vec3(0.0);
#
if (m.r > 0.01) {
#
float at = age - 0.28 - m.g * 0.75;
#
float on = clamp(at / 0.1, 0.0, 1.0);
#
float flare = (at > 0.0 && at < 0.4) ? 1.0 - at / 0.4 : 0.0;
#
float breathe = 0.5 + 0.5 * sin(t * 1.7 - m.g * 12.566);
#
c += glow * m.r * (on * (0.18 + 0.32 * breathe) + flare * 1.1);
#
}
#
if ((kinds & 1) != 0) {
#
float sp = mod(age - 0.9, 7.0);
#
if (age > 0.9 && sp < 1.3) {
#
float sc = -40.0 + sp / 1.3 * (gsP1.x + 220.0);
#
float d = (p.x + p.y * 0.6) - sc;
#
c += vec3(1.0, 0.925, 0.667) * 0.75 * exp(-d * d / 14.0) * str;
#
}
#
}
#
if ((kinds & 2) != 0) {
#
c += vec3(pow(max(0.0, sin(t * 1.9 + h * 0.8 + p.y * 0.05)), 12.0)) * str;
#
}
#
if ((kinds & 4) != 0) {
#
c += vec3(0.59, 0.78, 0.9) * str * (0.45 + 0.55 * sin(t * 9.0 - p.y * 1.1 + h * 2.0));
#
}
#
if ((kinds & 8) != 0) {
#
c += vec3(0.9, 0.92, 1.0) * str * pow(0.5 + 0.5 * sin(t * 2.4 + h * 40.0), 3.0);
#
}
#
if ((kinds & 16) != 0) {
#
float v = 0.06;
#
float bp = mod(age - 1.2, 9.0);
#
if (age > 1.2 && bp < 4.0) {
#
float bc = -40.0 + bp / 4.0 * (gsP1.x + 360.0);
#
float d = (p.x + p.y) - bc;
#
v += exp(-d * d / 450.0) * 0.75;
#
}
#
c += glow * v * str;
#
}
#
float a = clamp(max(c.r, max(c.g, c.b)), 0.0, 1.0);
#
return vec4(a > 0.0 ? c / a : vec3(0.0), a);
#
}
#
const vec2 vtS_wall = vec2(128.0, 256.0);
#
const vec2 vtS_pilaster = vec2(40.0, 243.0);
#
const vec2 vtS_uplight = vec2(112.0, 236.0);
#
const vec2 vtS_mote = vec2(3.0, 3.0);
#
const vec2 vtS_glow = vec2(96.0, 96.0);
#
const vec2 vtS_rays = vec2(256.0, 256.0);
#
const vec2 vtS_solid = vec2(4.0, 4.0);
#
const vec2 vtS_steam = vec2(26.0, 26.0);
#
const vec2 vtS_spark = vec2(7.0, 7.0);
#
const vec2 vtS_frame = vec2(244.0, 244.0);
#
const vec2 vtS_door = vec2(200.0, 200.0);
#
const vec2 vtS_door_top = vec2(200.0, 200.0);
#
const vec2 vtS_rod = vec2(66.0, 14.0);
#
const vec2 vtS_cam = vec2(22.0, 9.0);
#
const vec2 vtS_gear = vec2(116.0, 116.0);
#
const vec2 vtS_wheel = vec2(102.0, 102.0);
#
const vec2 vtS_hub = vec2(34.0, 34.0);
#
const vec2 vtS_straps = vec2(50.0, 200.0);
#
const vec2 vtS_hinge = vec2(30.0, 228.0);
#
const vec2 vtS_interior = vec2(192.0, 192.0);
#
const vec2 vtS_seal = vec2(212.0, 212.0);
#
const vec2 vtS_keypad = vec2(144.0, 236.0);
#
const vec2 vtS_key_lit = vec2(42.0, 34.0);
#
const vec2 vtS_led = vec2(15.0, 15.0);
#
const vec2 vtS_lock_shut = vec2(24.0, 34.0);
#
const vec2 vtS_lock_open = vec2(24.0, 34.0);
#
const vec2 vtS_coin = vec2(12.0, 12.0);
#
const vec2 vtS_ring = vec2(56.0, 56.0);
#
const vec2 vtS_digit = vec2(14.0, 26.0);
#
const int vtE_WALL = 0;
#
const int vtE_PILASTER = 1;
#
const int vtE_UPLIGHT = 3;
#
const int vtE_INTERIOR = 5;
#
const int vtE_INNER_LIGHT = 6;
#
const int vtE_FRAME = 7;
#
const int vtE_SEAL = 8;
#
const int vtE_DOOR = 9;
#
const int vtE_ROD = 10;
#
const int vtE_DOOR_TOP = 18;
#
const int vtE_CAM = 19;
#
const int vtE_GEAR = 23;
#
const int vtE_WHEEL = 24;
#
const int vtE_HUB = 25;
#
const int vtE_STRAPS = 26;
#
const int vtE_HINGE = 27;
#
const int vtE_KEYPAD = 28;
#
const int vtE_LED_GLOW = 29;
#
const int vtE_LED = 30;
#
const int vtE_LOCK_SHUT = 31;
#
const int vtE_LOCK_OPEN = 32;
#
const int vtE_LCD = 33;
#
const int vtE_KEY = 40;
#
const int vtE_MOTE = 100;
#
const int vtE_STEAM = 116;
#
const int vtE_SPARK = 132;
#
const int vtE_RAYS = 156;
#
const int vtE_BURST = 157;
#
const int vtE_FLASH = 158;
#
const int vtE_REFL = 160;
#
const int vtE_DEP_COIN = 224;
#
const int vtE_DEP_RING = 236;
#
const int vtE_WD_COIN = 240;
#
const int vtE_WD_RING = 252;
#
const int vtMOTES = 16;
#
const int vtSTEAMS = 16;
#
const int vtSPARKS = 24;
#
const int vtCOINS = 12;
#
const vec2 vtCANVAS = vec2(480.0, 270.0);
#
const float vtFLOOR_Y = 108.0;
#
const vec2 vtDOOR_C = vec2(-24.0, -12.0);
#
const float vtDOOR_R = 100.0;
#
const float vtOPENING_R = 96.0;
#
const float vtFRAME_R = 118.0;
#
const float vtHINGE_X = 84.0;
#
const float vtROD_R = 74.0;
#
const float vtROD_TRAVEL = 20.0;
#
const float vtBRACKET_R = 80.0;
#
const float vtCAM_R = 99.0;
#
const float vtCAM_TRAVEL = 14.0;
#
const float vtHI = 0.5;
#
const int vtRODS = 8;
#
const int vtCAMS = 4;
#
const float vtROD_A0 = 0.39270;
#
const vec2 vtPILASTERS = vec2(-212.0, 236.0);
#
const vec2 vtKEYPAD_C = vec2(176.0, -8.0);
#
const vec2 vtKEY_AT[10] = vec2[10](vec2(176.0, 39.0), vec2(156.0, -9.0), vec2(176.0, -9.0), vec2(196.0, -9.0), vec2(156.0, 7.0), vec2(176.0, 7.0), vec2(196.0, 7.0), vec2(156.0, 23.0), vec2(176.0, 23.0), vec2(196.0, 23.0));
#
const vec2 vtLCD_AT[6] = vec2[6](vec2(154.0, -42.0), vec2(163.0, -42.0), vec2(172.0, -42.0), vec2(181.0, -42.0), vec2(190.0, -42.0), vec2(199.0, -42.0));
#
const vec2 vtLOCK_AT = vec2(157.0, -24.0);
#
const vec2 vtLED_AT = vec2(196.0, -24.0);
#
const vec2 vtCHEST = vec2(176.0, 186.0);
#
const vec2 vtROOM_DOOR = vec2(88.0, 62.0);
#
const vec2 vtROOM_DEPOSIT = vec2(25.0, 62.0);
#
const vec2 vtROOM_WITHDRAW = vec2(151.0, 62.0);
#
const vec2 vtROOM_POCKET = vec2(88.0, 150.0);
#
SB_LOC(13) in vec4 vtLC;
#
SB_LOC(14) flat in vec4 vtA;
#
SB_LOC(15) flat in vec4 vtRect;
#
SB_LOC(16) flat in vec4 vtTint;
#
SB_LOC(17) flat in vec4 vtPlane;
#
SB_LOC(18) flat in vec4 vtPiv;
#
SB_LOC(19) flat in vec4 vtFx;
#
const float vtFOCAL_F = 800.0;
#
const float vtBAYER[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
#
float vtDither(vec2 p) {
#
ivec2 i = ivec2(mod(floor(p), 4.0));
#
return (vtBAYER[i.y * 4 + i.x] + 0.5) / 16.0;
#
}
#
vec4 vtAt(vec2 p) {
#
if (p.x < 0.0 || p.y < 0.0 || p.x >= vtRect.z || p.y >= vtRect.w) return vec4(0.0);
#
return textureLod(Sampler0, vtRect.xy + (floor(p) + 0.5) / vec2(textureSize(Sampler0, 0)), 0.0);
#
}
#
vec4 vtPre(vec2 p) {
#
vec4 c = vtAt(clamp(p, vec2(0.5), vtRect.zw - 0.5));
#
return vec4(c.rgb * c.a, c.a);
#
}
#
vec4 vtSmoothPre(vec2 p) {
#
if (p.x < 0.0 || p.y < 0.0 || p.x > vtRect.z || p.y > vtRect.w) return vec4(0.0);
#
vec2 q = p - 0.5;
#
vec2 i = floor(q);
#
vec2 f = q - i;
#
vec4 a = mix(vtPre(i + vec2(0.5, 0.5)), vtPre(i + vec2(1.5, 0.5)), f.x);
#
vec4 b = mix(vtPre(i + vec2(0.5, 1.5)), vtPre(i + vec2(1.5, 1.5)), f.x);
#
return mix(a, b, f.y);
#
}
#
vec4 vtStraight(vec4 c) {
#
return c.a > 0.0 ? vec4(c.rgb / c.a, c.a) : vec4(0.0);
#
}
#
vec4 vtSample(vec2 p) {
#
if (vtA.y > 0.5) return vtStraight(vtSmoothPre(p));
#
return vtAt(p);
#
}
#
vec4 vtWall(vec2 c) {
#
bool floorPart = c.y >= vtFLOOR_Y;
#
vec2 q = floorPart ? vec2(mod(c.x, 128.0), 128.0 + mod(c.y - vtFLOOR_Y, 128.0)) : mod(c, 128.0);
#
vec4 w = vtAt(q);
#
float lampL = vtTint.r;
#
float lampR = vtTint.g;
#
float open = vtTint.b;
#
float leak = vtPlane.x;
#
vec3 warm = vec3(1.0, 0.8, 0.5);
#
float light = 0.14;
#
vec3 add = vec3(0.0);
#
for (int i = 0; i < 2; i++) {
#
float lamp = i == 0 ? lampL : lampR;
#
float dx = (c.x - vtPILASTERS[i]) / 62.0;
#
if (floorPart) {
#
float dy = (c.y - vtFLOOR_Y) / 26.0;
#
light += lamp * exp(-dx * dx * 3.0) * exp(-dy) * 1.8;
#
add += warm * lamp * exp(-dx * dx * 14.0) * exp(-dy * 1.4) * 0.35;
#
} else {
#
float up = clamp((vtFLOOR_Y - c.y) / 240.0, 0.0, 1.0);
#
light += lamp * exp(-dx * dx) * (1.5 - 1.1 * up);
#
}
#
}
#
vec2 dd = c - vtDOOR_C;
#
float r = length(dd);
#
light += open * exp(-r * r / (170.0 * 170.0)) * 2.4;
#
float ring = (r - vtFRAME_R) / 14.0;
#
light += leak * exp(-ring * ring) * 1.2 * (r > vtFRAME_R ? 1.0 : 0.0);
#
if (floorPart) {
#
float fx = (c.x - vtDOOR_C.x) / 110.0;
#
add += warm * (open * 0.5 + leak * 0.12) * exp(-fx * fx) * exp(-(c.y - vtFLOOR_Y) / 30.0);
#
}
#
float vig = 1.0 - 0.55 * clamp(length(c / vec2(250.0, 150.0)) - 0.45, 0.0, 1.0);
#
vec3 rgb = w.rgb * light * vig * mix(vec3(1.0), warm * 1.3, clamp(open + leak * 0.3, 0.0, 1.0)) + add * vig;
#
return vec4(rgb, 1.0);
#
}
#
vec2 vtUnproject(vec2 c) {
#
if (vtPiv.w > 0.5) c.y = 2.0 * vtFLOOR_Y - c.y;
#
c = vtDOOR_C + (c - vtDOOR_C) / (1.0 + vtFx.w);
#
float x = c.x - vtHINGE_X;
#
float y = c.y - vtDOOR_C.y;
#
float px = x * vtFOCAL_F / (vtA.z * vtFOCAL_F - x * vtA.w);
#
float py = y * (vtFOCAL_F + px * vtA.w) / vtFOCAL_F;
#
return vec2(px, py);
#
}
#
vec2 vtLocalOf(vec2 pl, float extra) {
#
vec2 d = pl - vtPlane.xy;
#
float a = -(vtPlane.z + extra);
#
float cs = cos(a);
#
float sn = sin(a);
#
d = vec2(cs * d.x - sn * d.y, sn * d.x + cs * d.y) / vec2(vtPlane.w, vtPiv.z);
#
return d + vtPiv.xy;
#
}
#
vec4 vtOnPlane(vec2 c) {
#
vec2 pl = vtUnproject(c);
#
float blur = min(vtFx.x, 0.6);
#
if (blur < 0.02) return vtSample(vtLocalOf(pl, 0.0));
#
vec4 sum = vec4(0.0);
#
for (int k = -3; k <= 3; k++) {
#
sum += vtSmoothPre(vtLocalOf(pl, float(k) * blur / 6.0));
#
}
#
return vtStraight(sum / 7.0);
#
}
#
float vtSheenAt(vec2 p) {
#
float d = (p.x + p.y * 0.6) - vtFx.y;
#
return exp(-d * d / 70.0) * vtFx.z;
#
}
#
const float jnDROP = 30000.0;
#
const float jnSTEP = 6.0;
#
const float jnT_UNFOLD = 5.0;
#
const float jnT_TEXT_AT = 3.0;
#
const float jnT_TEXT = 5.0;
#
const float jnT_FILL_AT = 6.0;
#
const float jnT_FILL = 12.0;
#
const float jnT_SHINE_AT = 19.0;
#
const float jnT_SHINE = 10.0;
#
const float jnT_CELLS_AT = 4.0;
#
const float jnT_GAP = 1.0;
#
const float jnT_LIGHT = 5.0;
#
const float jnT_STAMP_AT = 10.0;
#
const float jnT_STAMP = 6.0;
#
const float jnT_CONFETTI = 30.0;
#
const float jnT_BAR_AT = 24.0;
#
const float jnT_BAR = 14.0;
#
const vec2 jnCARD_QUAD = vec2(178.0, 52.0);
#
const vec2 jnCARD_M = vec2(8.0, 8.0);
#
const vec2 jnCARD = vec2(162.0, 36.0);
#
const vec4 jnCARD_BAR = vec4(22.0, 21.0, 137.0, 11.0);
#
const vec2 jnCELL_QUAD = vec2(34.0, 34.0);
#
const vec2 jnCELL_M = vec2(8.0, 8.0);
#
const vec2 jnCELL = vec2(18.0, 18.0);
#
const vec2 jnFIRST_CELL = vec2(7.0, 71.0);
#
const vec2 jnBAR_QUAD = vec2(84.0, 28.0);
#
const vec2 jnBAR_M = vec2(8.0, 8.0);
#
const vec2 jnBAR = vec2(68.0, 12.0);
#
const vec2 jnWINDOW = vec2(176.0, 222.0);
#
float jnHash(vec2 p) {
#
return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
#
}
#
float jnOut3(float u) {
#
float v = 1.0 - clamp(u, 0.0, 1.0);
#
return 1.0 - v * v * v;
#
}
#
vec3 jnHex(float r, float g, float b) {
#
return vec3(r, g, b) / 255.0;
#
}
#
void jnWell(int k, out vec3 face, out vec3 hi, out vec3 lo) {
#
if (k == 1) {
#
face = jnHex(122.0, 90.0, 30.0); hi = jnHex(214.0, 172.0, 80.0); lo = jnHex(74.0, 52.0, 18.0);
#
} else if (k == 2) {
#
face = jnHex(47.0, 90.0, 41.0); hi = jnHex(75.0, 138.0, 63.0); lo = jnHex(29.0, 58.0, 25.0);
#
} else if (k == 3) {
#
face = jnHex(30.0, 23.0, 18.0); hi = jnHex(44.0, 34.0, 26.0); lo = jnHex(18.0, 13.0, 10.0);
#
} else if (k == 4) {
#
face = jnHex(132.0, 92.0, 34.0); hi = jnHex(222.0, 178.0, 86.0); lo = jnHex(82.0, 56.0, 20.0);
#
} else {
#
face = jnHex(70.0, 55.0, 40.0); hi = jnHex(96.0, 76.0, 55.0); lo = jnHex(42.0, 32.0, 24.0);
#
}
#
}
#
vec3 jnMist(vec3 c, vec2 p, float t) {
#
float x = p.x * 0.25 + t * 0.08;
#
vec2 q = floor(vec2(x, p.y * 0.34));
#
float m = mix(jnHash(q), jnHash(q + vec2(1.0, 0.0)), fract(x));
#
return mix(c, jnHex(70.0, 60.0, 52.0), 0.12 * smoothstep(0.55, 0.95, m));
#
}
#
vec4 jnCellPaint(vec2 local, int s, int flags, float a, float t, float idx) {
#
vec2 p = floor(local) - jnCELL_M;
#
bool gift = (flags & 1) == 1;
#
bool party = (flags & 2) == 2;
#
int k = gift ? 4 : (s == 1 ? 1 : (s == 2 ? 2 : (s == 4 ? 3 : 0)));
#
float tau = a - jnT_STAMP_AT;
#
if (party && tau < 0.0) k = 0;
#
if (party && tau >= 0.0 && tau < jnT_STAMP) {
#
p.x -= floor(sin(tau * 5.0) * 1.5 * (1.0 - tau / jnT_STAMP) + 0.5);
#
}
#
float pulse = 0.5 + 0.5 * sin(t * 6.2832 / 40.0);
#
bool whole = gift && s == 2;
#
vec4 outc = vec4(0.0);
#
if (party && tau > 0.0 && tau < jnT_CONFETTI) {
#
for (int i = 0; i < 14; i++) {
#
float h1 = jnHash(vec2(float(i), idx));
#
float h2 = jnHash(vec2(float(i) * 1.7, idx + 3.1));
#
float ang = 6.2832 * h1;
#
vec2 at = vec2(8.5, 8.5) + vec2(cos(ang), sin(ang)) * (5.0 + 4.0 * h2) * jnOut3(tau / 10.0)
#
+ vec2(0.0, 0.008 * tau * tau);
#
vec2 d = abs(p - floor(at + 0.5));
#
float size = h2 > 0.6 ? 1.0 : 0.0;
#
if (d.x <= size && d.y <= size) {
#
float hue = jnHash(vec2(float(i), 9.0 + idx));
#
vec3 c = hue < 0.25 ? jnHex(255.0, 215.0, 106.0) : hue < 0.5 ? jnHex(155.0, 232.0, 135.0)
#
: hue < 0.75 ? jnHex(255.0, 255.0, 255.0) : jnHex(110.0, 180.0, 255.0);
#
outc = vec4(c, clamp((jnT_CONFETTI - tau) / 8.0, 0.0, 1.0));
#
}
#
}
#
}
#
bool well = p.x >= 1.0 && p.x <= 16.0 && p.y >= 1.0 && p.y <= 16.0;
#
bool corner = (p.x == 1.0 || p.x == 16.0) && (p.y == 1.0 || p.y == 16.0);
#
if (!well || corner) {
#
vec2 dd = max(max(vec2(1.0) - p, p - vec2(16.0)), 0.0);
#
float dist = max(dd.x, dd.y);
#
if (a >= 0.0 && a < 6.0 && k != 3) {
#
float r = 1.0 + a * 1.1;
#
if (abs(dist - r) < 0.6) {
#
vec3 rc = k == 1 || k == 4 ? jnHex(255.0, 222.0, 130.0) : (k == 2 ? jnHex(160.0, 240.0, 130.0)
#
: jnHex(243.0, 230.0, 204.0));
#
outc = vec4(rc, 0.55 * (1.0 - a / 6.0));
#
}
#
}
#
if (a >= 0.0 && (k == 1 || whole) && dist > 0.0 && dist <= 2.0) {
#
vec3 gc = k == 1 ? jnHex(255.0, 210.0, 110.0) : jnHex(255.0, 190.0, 80.0);
#
outc = vec4(gc, (0.55 - 0.2 * dist) * (0.45 + 0.55 * pulse));
#
}
#
if (party && tau >= 0.0 && tau < 6.0 && dist > 0.0 && dist <= 3.0) {
#
outc = vec4(1.0, 1.0, 0.9, (1.0 - tau / 6.0) * (0.7 - 0.15 * dist));
#
}
#
return outc;
#
}
#
vec3 face, hi, lo;
#
jnWell(k, face, hi, lo);
#
vec3 c = face;
#
if (p.x == 1.0 || p.y == 1.0) c = hi;
#
else if (p.x == 16.0 || p.y == 16.0) c = lo;
#
if (k == 1) c = mix(c, jnHex(255.0, 220.0, 120.0), 0.2 * pulse);
#
if (k == 3) c = jnMist(c, p + vec2(idx * 18.0, 0.0), t);
#
if (whole) {
#
c = mix(c, jnHex(255.0, 214.0, 106.0), 0.25 * pulse);
#
float tw = jnHash(vec2(floor(t / 9.0), idx));
#
vec2 star = vec2(2.0 + floor(tw * 13.0), 2.0 + floor(fract(tw * 7.3) * 13.0));
#
if (p == star) c = vec3(1.0);
#
}
#
if (a < 0.0) {
#
return vec4(mix(c, jnHex(20.0, 15.0, 11.0), 0.72), 1.0);
#
}
#
if (a < jnT_LIGHT) c = mix(vec3(1.0), c, jnOut3(a / jnT_LIGHT));
#
if (party && tau >= 0.0 && tau < 4.0) c = mix(c, vec3(1.0), 0.75 * (1.0 - tau / 4.0));
#
return vec4(c, 1.0);
#
}
#
vec4 jnCardPaint(vec2 local, int s, int data, float a, float t) {
#
if (a < 0.0) return vec4(0.0);
#
vec2 p = floor(local) - jnCARD_M;
#
int look = s == 3 ? 1 : (data == 63 ? 2 : (data == 62 ? 3 : 0));
#
float prog = look == 1 ? float(data) / 63.0 : (look == 0 ? float(data) / 61.0 : 1.0);
#
float pulse = 0.5 + 0.5 * sin(t * 6.2832 / 40.0);
#
vec3 top = jnHex(48.0, 37.0, 27.0);
#
vec3 bot = jnHex(36.0, 27.0, 19.0);
#
vec3 rim = jnHex(92.0, 72.0, 50.0);
#
if (look == 1) {
#
top = jnHex(62.0, 46.0, 22.0); bot = jnHex(44.0, 32.0, 15.0);
#
rim = mix(jnHex(120.0, 90.0, 36.0), jnHex(255.0, 222.0, 130.0), pulse);
#
} else if (look == 2) {
#
top = jnHex(33.0, 50.0, 28.0); bot = jnHex(24.0, 38.0, 22.0);
#
rim = mix(jnHex(160.0, 124.0, 52.0), jnHex(240.0, 200.0, 110.0), 0.5 + 0.5 * sin(t * 6.2832 / 80.0));
#
} else if (look == 3) {
#
top = jnHex(26.0, 20.0, 16.0); bot = jnHex(19.0, 15.0, 12.0); rim = jnHex(10.0, 8.0, 6.0);
#
}
#
float shown = mix(18.0, jnCARD.x, jnOut3(a / jnT_UNFOLD));
#
bool body = p.x >= 0.0 && p.x < shown && p.y >= 0.0 && p.y < jnCARD.y;
#
bool corner = (p.x == 0.0 || p.x >= shown - 1.0) && (p.y == 0.0 || p.y == jnCARD.y - 1.0);
#
vec2 bar = p - jnCARD_BAR.xy;
#
float barW = jnCARD_BAR.z - 2.0;
#
float f = look == 3 ? 0.0 : prog * jnOut3((a - jnT_FILL_AT) / jnT_FILL);
#
float filled = floor(barW * f + 0.5);
#
if (!body || corner) {
#
vec4 outc = vec4(0.0);
#
vec2 dd = max(max(-p, p - (jnCARD - 1.0)), 0.0);
#
float dist = max(dd.x, dd.y);
#
if ((look == 1 || look == 2) && a > jnT_UNFOLD && dist > 0.0 && dist <= 2.0) {
#
vec3 gc = look == 1 ? jnHex(255.0, 210.0, 110.0) : jnHex(240.0, 200.0, 110.0);
#
outc = vec4(gc, (0.34 - 0.12 * dist) * (0.6 + 0.4 * pulse));
#
}
#
return outc;
#
}
#
float fade = clamp(a / 2.0 + 0.4, 0.0, 1.0);
#
vec3 c = mix(top, bot, p.y / (jnCARD.y - 1.0));
#
bool edge = p.x == 0.0 || p.y == 0.0 || p.y == jnCARD.y - 1.0 || p.x >= shown - 1.0;
#
if (edge) {
#
c = rim;
#
} else if (p.x < 18.0 && p.y < 18.0) {
#
vec3 face, hi, lo;
#
jnWell(look == 1 ? 1 : (look == 2 ? 2 : (look == 3 ? 3 : 0)), face, hi, lo);
#
c = face;
#
if (p.x == 17.0 || p.y == 17.0) c = rim * 0.7;
#
else if (p.x == 1.0 || p.y == 1.0) c = hi;
#
else if (p.x == 16.0 || p.y == 16.0) c = lo;
#
if (look == 1) c = mix(c, jnHex(255.0, 220.0, 120.0), 0.18 * pulse);
#
} else if (look != 3 && bar.x >= 0.0 && bar.x < jnCARD_BAR.z && bar.y >= 0.0 && bar.y < jnCARD_BAR.w) {
#
bool rimBar = bar.x == 0.0 || bar.y == 0.0 || bar.x == jnCARD_BAR.z - 1.0 || bar.y == jnCARD_BAR.w - 1.0;
#
bool cut = (bar.x == 0.0 || bar.x == jnCARD_BAR.z - 1.0) && (bar.y == 0.0 || bar.y == jnCARD_BAR.w - 1.0);
#
if (cut) {
#
c = mix(top, bot, p.y / (jnCARD.y - 1.0));
#
} else if (rimBar) {
#
c = jnHex(18.0, 13.0, 9.0);
#
} else {
#
float x = bar.x - 1.0;
#
float v = (bar.y - 1.0) / (jnCARD_BAR.w - 3.0);
#
c = mix(jnHex(20.0, 15.0, 11.0), jnHex(30.0, 23.0, 17.0), v);
#
if (x < filled) {
#
vec3 ft = look == 1 ? jnHex(226.0, 170.0, 58.0) : (look == 2 ? jnHex(255.0, 214.0, 106.0)
#
: jnHex(90.0, 170.0, 70.0));
#
vec3 fb = look == 1 ? jnHex(150.0, 98.0, 24.0) : (look == 2 ? jnHex(178.0, 128.0, 40.0)
#
: jnHex(45.0, 100.0, 38.0));
#
c = mix(ft, fb, v);
#
if (bar.y == 1.0) c = mix(c, vec3(1.0), 0.18);
#
if (x >= filled - 1.0 && a < jnT_FILL_AT + jnT_FILL) c = mix(c, vec3(1.0), 0.7);
#
float sh = (a - jnT_SHINE_AT) / jnT_SHINE;
#
if (look == 2) sh = mod(t, 60.0) / 14.0;
#
if (sh > 0.0 && sh < 1.0) {
#
float bx = sh * (filled + 16.0) - 8.0;
#
float d = abs(x - bx + (bar.y - 5.0) * 0.6);
#
if (d < 2.5) c = mix(c, vec3(1.0), 0.3 * (1.0 - d / 2.5));
#
}
#
}
#
}
#
} else if (p.y == 1.0) {
#
c = mix(c, vec3(1.0), 0.06);
#
}
#
if (look == 3 && !edge) c = jnMist(c, p, t);
#
return vec4(c, fade);
#
}
#
vec4 jnBarPaint(vec2 local, float prog, float a, float t) {
#
if (a < 0.0) return vec4(0.0);
#
vec2 p = floor(local) - jnBAR_M;
#
bool whole = prog > 0.999;
#
if (p.x < 0.0 || p.y < 0.0 || p.x >= jnBAR.x || p.y >= jnBAR.y) {
#
if (whole) {
#
vec2 dd = max(max(-p, p - (jnBAR - 1.0)), 0.0);
#
float dist = max(dd.x, dd.y);
#
if (dist <= 3.0) return vec4(jnHex(255.0, 210.0, 110.0), (0.3 - 0.08 * dist) * (0.6 + 0.4 * sin(t * 0.2)));
#
}
#
return vec4(0.0);
#
}
#
if ((p.x == 0.0 || p.x == jnBAR.x - 1.0) && (p.y == 0.0 || p.y == jnBAR.y - 1.0)) return vec4(0.0);
#
float fade = clamp(a / 3.0, 0.0, 1.0);
#
bool edge = p.x == 0.0 || p.y == 0.0 || p.x == jnBAR.x - 1.0 || p.y == jnBAR.y - 1.0;
#
if (edge) return vec4(whole ? jnHex(201.0, 162.0, 75.0) : jnHex(18.0, 13.0, 9.0), fade);
#
vec3 c = mix(jnHex(20.0, 15.0, 11.0), jnHex(30.0, 23.0, 17.0), p.y / jnBAR.y);
#
float f = prog * jnOut3(a / jnT_BAR);
#
float x = p.x - 1.0;
#
float filled = floor((jnBAR.x - 2.0) * f + 0.5);
#
if (x < filled) {
#
vec3 top = whole ? jnHex(255.0, 214.0, 106.0) : jnHex(90.0, 170.0, 70.0);
#
vec3 bot = whole ? jnHex(178.0, 128.0, 40.0) : jnHex(45.0, 100.0, 38.0);
#
c = mix(top, bot, (p.y - 1.0) / (jnBAR.y - 3.0));
#
if (x >= filled - 1.0 && a < jnT_BAR) c = mix(c, vec3(1.0), 0.7);
#
float period = whole ? 50.0 : 120.0;
#
float sh = mod(t, period) / 14.0;
#
if (sh < 1.0) {
#
float bx = sh * (filled + 16.0) - 8.0;
#
float d = abs(x - bx + (p.y - 6.0) * 0.6);
#
if (d < 2.5) c = mix(c, vec3(1.0), 0.3 * (1.0 - d / 2.5));
#
}
#
}
#
return vec4(c, fade);
#
}
#
SB_LOC(20) flat in float csOn;
#
SB_LOC(21) in vec2 csLocal;
#
SB_LOC(22) in vec2 csCanvas;
#
SB_LOC(23) in vec4 csTint;
#
SB_LOC(24) flat in vec4 csTint2;
#
SB_LOC(25) flat in vec4 csRect;
#
SB_LOC(26) flat in vec2 csSz;
#
SB_LOC(27) flat in vec4 csFx;
#
SB_LOC(28) flat in vec4 csFx2;
#
SB_LOC(29) flat in vec4 csClip;
#
SB_LOC(30) flat in vec2 csDisp;
#
vec4 csAt(vec2 p) {
#
if (p.x < 0.0 || p.y < 0.0 || p.x >= csSz.x || p.y >= csSz.y) return vec4(0.0);
#
vec4 c = textureLod(Sampler0, csRect.xy + (floor(p) + 0.5) * csRect.zw, 0.0);
#
return vec4(c.rgb * c.a, c.a);
#
}
#
vec4 csAtClamped(vec2 p) {
#
return csAt(clamp(p, vec2(0.5), csSz - 0.5));
#
}
#
vec4 csSmooth(vec2 p) {
#
vec2 q = p - 0.5;
#
vec2 i = floor(q);
#
vec2 f = q - i;
#
vec4 a = mix(csAtClamped(i + vec2(0.5, 0.5)), csAtClamped(i + vec2(1.5, 0.5)), f.x);
#
vec4 b = mix(csAtClamped(i + vec2(0.5, 1.5)), csAtClamped(i + vec2(1.5, 1.5)), f.x);
#
vec4 c = mix(a, b, f.y);
#
if (p.x < 0.0 || p.y < 0.0 || p.x > csSz.x || p.y > csSz.y) c = vec4(0.0);
#
return c;
#
}
#
vec4 csCrisp(vec2 p) {
#
vec2 w = max(fwidth(p), vec2(1.0e-4));
#
vec2 seam = floor(p + 0.5);
#
return csSmooth(seam + clamp((p - seam) / w, -0.5, 0.5));
#
}
#
vec4 csBlurX(vec2 p, float len) {
#
vec4 sum = vec4(0.0);
#
for (int k = -4; k <= 4; k++) {
#
sum += csAt(p + vec2(float(k) * len * 0.25, 0.0));
#
}
#
return sum / 9.0;
#
}
#
vec4 csStrip(vec2 p, float roll, float blur) {
#
float cell = csSz.y / 10.0;
#
vec4 sum = vec4(0.0);
#
for (int k = -3; k <= 3; k++) {
#
float y = mod(p.y + roll * cell + float(k) * blur / 3.0, csSz.y);
#
sum += csAt(vec2(p.x, y));
#
}
#
return sum / 7.0;
#
}
#
const float gbF_PI2 = 6.28318;
#
float gbFSat(float x) {
#
return clamp(x, 0.0, 1.0);
#
}
#
float gbDither(vec2 p) {
#
ivec2 i = ivec2(mod(floor(p), 4.0));
#
int xy = i.x ^ i.y;
#
int v = (xy & 1) * 8 + (i.y & 1) * 4 + ((xy >> 1) & 1) * 2 + ((i.y >> 1) & 1);
#
return (float(v) + 0.5) / 16.0;
#
}
#
float gbSteps(float v, float levels, vec2 p) {
#
return clamp(floor(v * (levels - 1.0) + gbDither(p)) / (levels - 1.0), 0.0, 1.0);
#
}
#
float gbFHash(vec2 p) {
#
return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
#
}
#
float gbTurn(vec2 p) {
#
return fract(atan(p.x, -p.y) / gbF_PI2);
#
}
#
vec3 gbGold(float v) {
#
if (v < 0.25) return vec3(0.6, 0.32, 0.06);
#
if (v < 0.5) return vec3(0.91, 0.6, 0.13);
#
if (v < 0.75) return vec3(1.0, 0.79, 0.24);
#
return vec3(1.0, 0.96, 0.69);
#
}
#
vec3 gbZoneColour(float band, float phi, float r, vec2 p, float lit) {
#
float shine = pow(0.5 + 0.5 * sin(csFx2.z * 0.35 - phi * 25.0 + r * 0.15), 6.0);
#
vec3 c = gbGold(gbSteps(gbFSat(0.25 + 0.6 * band + 0.35 * shine) * min(lit, 1.3), 4.0, p));
#
float star = step(0.965, gbFHash(floor(p * 0.5) + floor(csFx2.z * 0.25)));
#
return c + vec3(star * 0.7);
#
}
#
vec3 gbLoseColour(float phi, float band) {
#
bool odd = mod(floor(phi * 32.0), 2.0) < 1.0;
#
return (odd ? vec3(0.42, 0.06, 0.1) : vec3(0.29, 0.04, 0.07)) * (0.65 + 0.5 * band);
#
}
#
vec3 gbDiscAt(float phi, float r, float arc, vec2 p, float lit) {
#
float seg = fract(phi * 32.0);
#
bool inZone = phi < arc;
#
float band = gbFSat((r - 16.0) / (csClip.x - 19.0));
#
vec3 c = inZone ? gbZoneColour(band, phi, r, p, lit) : gbLoseColour(phi, band);
#
if (seg < 0.05 || seg > 0.975) c *= inZone ? 1.15 : 0.55;
#
float px = gbF_PI2 * r;
#
float edge = min(min(phi, 1.0 - phi), abs(phi - arc)) * px;
#
if (edge < 1.6) c = vec3(1.0, 0.98, 0.9);
#
float peg = min(seg, 1.0 - seg) * px / 32.0;
#
if (r > csClip.x - 7.0 && r < csClip.x - 4.0 && peg < 1.0) c = inZone ? vec3(1.0) : vec3(0.55, 0.5, 0.6);
#
return c;
#
}
#
vec4 gbDisc() {
#
vec2 p = floor(csLocal) + 0.5;
#
float r = length(p);
#
float big = csClip.x;
#
if (r >= csClip.z + 0.5) return vec4(0.0);
#
float a = gbTurn(p);
#
if (r >= csClip.y) {
#
float edge = min(r - csClip.y, csClip.z - r);
#
vec3 c = vec3(0.05, 0.02, 0.1);
#
float al = 0.88;
#
if (edge < 1.0) {
#
c = r - csClip.y < 1.0 ? vec3(1.0, 0.3, 0.85) : vec3(0.35, 0.95, 1.0);
#
al = 1.0;
#
}
#
return vec4(c, al);
#
}
#
if (r >= big) {
#
float z = fract(a + csFx.z);
#
bool lit = z < csFx.y;
#
vec3 halo = vec3(1.0, 0.8, 0.25);
#
return lit ? vec4(halo * (0.75 + 0.25 * sin(csFx2.z * 0.5)), 1.0) : vec4(0.02, 0.01, 0.05, 0.9);
#
}
#
vec3 c;
#
if (r >= big - 3.0) {
#
float light = 0.5 + 0.5 * cos((a - 0.875) * gbF_PI2);
#
c = gbGold(gbSteps(light * 0.8 + (r >= big - 1.0 ? 0.0 : 0.15), 4.0, p));
#
} else if (r < 13.0) {
#
c = vec3(0.04, 0.02, 0.08) + vec3(0.25, 0.1, 0.3) * (1.0 - r / 13.0) * 0.5;
#
} else if (r < 15.0) {
#
float light = 0.5 + 0.5 * cos((a - 0.875) * gbF_PI2);
#
c = gbGold(gbSteps(light, 4.0, p));
#
} else {
#
float arc = csFx.y;
#
float theta = csFx.z;
#
float spd = abs(csFx.w);
#
float span = clamp(spd * 0.6, 0.0, 0.14);
#
float lit = (1.0 + 0.35 * csSz.x) * (1.0 + 0.3 * csFx2.w);
#
vec3 sum = vec3(0.0);
#
for (int k = 0; k < 6; k++) {
#
float phi = fract(a + theta + span * float(k) / 6.0);
#
sum += gbDiscAt(phi, r, arc, p, lit);
#
}
#
c = sum / 6.0;
#
}
#
float flood = csFx2.x;
#
if (flood > 0.0) {
#
float d = min(a, 1.0 - a);
#
float reach = flood * 0.52;
#
if (d < reach) {
#
float lead = gbFSat(1.0 - (reach - d) * 12.0);
#
float sparkle = step(0.93, gbFHash(p + floor(csFx2.z * 3.0)));
#
float lum = dot(c, vec3(0.3, 0.55, 0.15));
#
c = mix(c, csTint2.rgb * (0.45 + 0.9 * lum + 0.25 * gbFSat(r / big)), 0.85) + vec3(lead * 0.8 + sparkle * 0.6);
#
}
#
}
#
float dead = csFx2.y;
#
if (dead > 0.0) {
#
float g = dot(c, vec3(0.3, 0.55, 0.15));
#
float flick = step(0.25, gbFHash(vec2(floor(csFx2.z * 2.0), 3.0)));
#
c = mix(c, vec3(g * 0.55, g * 0.25, g * 0.3), dead) * (1.0 - 0.45 * dead * flick);
#
}
#
float hit = csClip.w;
#
if (hit > 0.0) {
#
c += vec3(1.0, 0.95, 0.85) * hit * exp(-length(p - vec2(0.0, -big)) / 18.0);
#
}
#
return vec4(c, 1.0);
#
}
#
vec3 gbSceneWarp(vec2 c) {
#
float t = csFx2.z;
#
float d = length(c);
#
float a = gbTurn(c);
#
float s = csFx.y;
#
vec3 col = mix(vec3(0.01, 0.0, 0.05), vec3(0.08, 0.02, 0.18), gbSteps(gbFSat(1.0 - d / 300.0), 5.0, c));
#
float z0 = 900.0 / (d + 20.0) + s * 1.5;
#
float z1 = 900.0 / (d + 21.0) + s * 1.5;
#
if (d > 60.0 && floor(z0 / 3.0) != floor(z1 / 3.0)) {
#
vec3 ring = mix(vec3(0.25, 0.95, 1.0), vec3(1.0, 0.3, 0.85), 0.5 + 0.5 * sin(a * 12.566 + t * 0.05));
#
col = mix(col, mix(ring, csTint2.rgb, csFx.z), 0.45 * gbFSat((d - 60.0) / 60.0));
#
}
#
float lane = floor(a * 90.0);
#
float h = gbFHash(vec2(lane, 7.0));
#
if (h > 0.55) {
#
float head = mod(h * 900.0 + s * 60.0 * (0.6 + h), 360.0) + 50.0;
#
float len = 6.0 + 60.0 * gbFSat(csFx.w * 4.0);
#
float k = gbFSat(1.0 - (head - d) / len) * step(d, head);
#
col += mix(vec3(0.8, 0.9, 1.0), vec3(1.0, 0.5, 0.9), h) * 0.7 * k * k;
#
}
#
col *= 1.0 - 0.55 * csClip.z;
#
return col;
#
}
#
vec4 gbBackdrop() {
#
vec2 c = floor(csCanvas) + 0.5;
#
float d = length(c - vec2(0.0, -2.0));
#
vec3 col = gbSceneWarp(c);
#
col += csTint2.rgb * csFx2.x * 0.3 * exp(-d / 110.0);
#
if (mod(floor(c.y), 2.0) < 1.0) col *= 0.84;
#
vec2 v = (floor(csCanvas) + 0.5) / max(csSz * 0.5, vec2(1.0));
#
float vig = length(v * vec2(0.8, 1.0));
#
col *= 1.0 - 0.6 * smoothstep(0.55, 1.4, vig);
#
col = mix(col, vec3(0.55, 0.0, 0.06), csFx2.y * 0.4 * smoothstep(0.3, 1.2, vig));
#
return vec4(col, csFx2.w);
#
}
#
vec4 gbTrail() {
#
vec2 p = floor(csLocal) + 0.5;
#
float r = length(p);
#
float d = fract(gbTurn(p) - csFx.y);
#
float len = max(csFx.z, 0.001);
#
if (d > len) return vec4(0.0);
#
float k = 1.0 - d / len;
#
float w = csFx2.x;
#
float x = (r - csFx.w) / w;
#
float rad = exp(-x * x);
#
vec3 col = mix(csTint2.rgb, csTint.rgb, k);
#
float al = pow(k, 1.4) * rad;
#
return vec4(mix(col, vec3(1.0), k * k * 0.6), gbSteps(al, 5.0, p));
#
}
#
vec4 gbCrtMask() {
#
vec2 c = csCanvas;
#
float h = csFx.y;
#
float w = csFx.z;
#
float dy = abs(c.y) - h;
#
float dx = abs(c.x) - w;
#
if (dx < 0.0 && dy < 0.0) {
#
float e = max(dx, dy);
#
return vec4(0.85, 0.95, 1.0, exp(e / 3.0) * 0.9 + csFx.w);
#
}
#
if (dx < 0.0 && dy < 1.5 && csFx.w > 0.5) return vec4(1.0);
#
return vec4(0.0, 0.0, 0.0, 1.0);
#
}
#
const vec2 crS_solid = vec2(4.0, 4.0);
#
const vec2 crS_glow = vec2(64.0, 64.0);
#
const vec2 crS_ring = vec2(128.0, 128.0);
#
const vec2 crS_rays = vec2(256.0, 256.0);
#
const vec2 crS_streak = vec2(96.0, 4.0);
#
const vec2 crS_spark = vec2(11.0, 11.0);
#
const vec2 crS_coin = vec2(13.0, 13.0);
#
const vec2 crS_confetti = vec2(6.0, 4.0);
#
const vec2 crS_vignette = vec2(256.0, 144.0);
#
const vec2 crS_petal = vec2(7.0, 6.0);
#
const vec2 crS_shard = vec2(13.0, 11.0);
#
const vec2 crS_lantern = vec2(9.0, 13.0);
#
const vec2 crS_dragon_head = vec2(44.0, 30.0);
#
const vec2 crS_dragon_body = vec2(16.0, 16.0);
#
const vec2 crS_dragon_tail = vec2(22.0, 16.0);
#
const vec2 crS_dragon_claw = vec2(12.0, 12.0);
#
const vec2 crS_koi_head = vec2(44.0, 30.0);
#
const vec2 crS_koi_body = vec2(16.0, 16.0);
#
const vec2 crS_koi_tail = vec2(22.0, 16.0);
#
const vec2 crS_koi_fin = vec2(12.0, 12.0);
#
const vec2 crS_firefly = vec2(7.0, 7.0);
#
const vec2 crS_lotus = vec2(14.0, 10.0);
#
const vec2 crS_phoenix_head = vec2(44.0, 30.0);
#
const vec2 crS_phoenix_body = vec2(16.0, 16.0);
#
const vec2 crS_phoenix_plume = vec2(16.0, 16.0);
#
const vec2 crS_phoenix_tail = vec2(22.0, 16.0);
#
const vec2 crS_phoenix_wing = vec2(40.0, 28.0);
#
const vec2 crS_ember = vec2(5.0, 7.0);
#
const vec2 crS_star = vec2(7.0, 7.0);
#
const vec2 crS_key = vec2(16.0, 16.0);
#
const vec2 crS_lot = vec2(32.0, 32.0);
#
const vec2 crS_big = vec2(22.0, 30.0);
#
const vec2 crA_big = vec2(2.0, 22.0);
#
const vec2 crS_small = vec2(11.0, 15.0);
#
const vec2 crA_small = vec2(1.0, 11.0);
#
const vec3 crRAR[4] = vec3[4](vec3(0.8588, 0.9020, 1.0000), vec3(0.2510, 0.8000, 1.0000), vec3(0.8000, 0.4000, 1.0000), vec3(1.0000, 0.7804, 0.2196));
#
const vec3 crCRATE[4] = vec3[4](vec3(0.9098, 0.5294, 0.2275), vec3(0.3608, 0.6588, 1.0000), vec3(1.0000, 0.8235, 0.2902), vec3(1.0000, 0.7059, 0.2392));
#
const float crF_PI2 = 6.28318;
#
float crFSat(float x) {
#
return clamp(x, 0.0, 1.0);
#
}
#
float crDither(vec2 p) {
#
ivec2 i = ivec2(mod(floor(p), 4.0));
#
int xy = i.x ^ i.y;
#
int v = (xy & 1) * 8 + (i.y & 1) * 4 + ((xy >> 1) & 1) * 2 + ((i.y >> 1) & 1);
#
return (float(v) + 0.5) / 16.0;
#
}
#
float crSteps(float v, float levels, vec2 p) {
#
return clamp(floor(v * (levels - 1.0) + crDither(p)) / (levels - 1.0), 0.0, 1.0);
#
}
#
float crFHash(vec2 p) {
#
return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
#
}
#
float crEaseIO(float u) {
#
float x = crFSat(u);
#
return x * x * (3.0 - 2.0 * x);
#
}
#
vec3 crStars(vec3 c, vec2 p, float t, float h, float rate) {
#
vec2 cell = floor(p / 4.0);
#
float hs = crFHash(cell);
#
vec2 star = cell * 4.0 + 1.5 + floor(vec2(crFHash(cell + 7.0), crFHash(cell + 9.0)) * 2.0);
#
if (hs > rate && abs(p.x - star.x) < 0.6 && abs(p.y - star.y) < 0.6) {
#
c += vec3(0.75) * (0.45 + 0.55 * sin(t * 0.3 + hs * 90.0)) * (1.0 - h);
#
}
#
return c;
#
}
#
vec3 crTorii(vec3 c, vec2 p, vec3 base, float ground) {
#
vec2 q = vec2(abs(p.x) - 182.0, p.y - ground);
#
float lift = (q.x / 36.0) * (q.x / 36.0) * 5.0;
#
bool pillar = abs(abs(q.x) - 22.0) < 3.0 && q.y > -66.0 && q.y < 0.0;
#
bool kasagi = abs(q.x) < 38.0 && q.y > -76.0 - lift && q.y < -68.0 - lift * 0.6;
#
bool nuki = abs(q.x) < 30.0 && q.y > -56.0 && q.y < -51.0;
#
bool gaku = abs(q.x) < 3.0 && q.y > -68.0 && q.y < -56.0;
#
if (pillar || kasagi || nuki || gaku) {
#
c = vec3(0.025, 0.018, 0.035);
#
if ((kasagi && q.y < -74.0 - lift) || (pillar && q.x < -22.0)) c = mix(c, base * 0.8 + vec3(0.1), 0.45);
#
}
#
return c;
#
}
#
vec3 crPagoda(vec3 c, vec2 p, vec3 rim) {
#
vec2 q = vec2(abs(p.x) - 190.0, p.y - 78.0);
#
bool on = false;
#
bool lit = false;
#
for (int k = 0; k < 3; k++) {
#
float fk = float(k);
#
float y0 = -24.0 - fk * 24.0;
#
float wroof = 36.0 - fk * 8.0;
#
float lift = (q.x / wroof) * (q.x / wroof) * 6.0;
#
if (abs(q.x) < wroof && q.y > y0 - 6.0 - lift && q.y < y0 - lift * 0.4) {
#
on = true;
#
lit = lit || q.y < y0 - 4.5 - lift;
#
}
#
if (abs(q.x) < 15.0 - fk * 3.0 && q.y >= y0 && q.y < y0 + 24.0) on = true;
#
}
#
if (abs(q.x) < 1.5 && q.y > -100.0 && q.y < -70.0) on = true;
#
if (on) c = lit ? mix(vec3(0.03, 0.01, 0.015), rim, 0.5) : vec3(0.03, 0.01, 0.015);
#
return c;
#
}
#
vec3 crNightJade(vec2 p, float t, vec3 base, float scroll) {
#
float h = crFSat((p.y + 150.0) / 224.0);
#
float hq = crSteps(h, 8.0, p);
#
vec3 top = base * 0.04 + vec3(0.004, 0.018, 0.02);
#
vec3 hor = base * 0.3 + vec3(0.02, 0.06, 0.05);
#
vec3 c = mix(top, hor, hq * hq);
#
c = crStars(c, p, t, h, 0.985);
#
vec2 mc = vec2(84.0, -92.0);
#
float dm = length(p - mc);
#
vec3 moon = mix(vec3(1.0, 0.98, 0.88), base, 0.2);
#
c += base * 0.4 * exp(-max(dm - 26.0, 0.0) / 30.0);
#
if (dm < 26.0) c = mix(c, moon * (0.7 + 0.3 * crSteps(crFSat(1.0 - dm / 30.0), 4.0, p)), 0.92);
#
float water = 74.0;
#
if (p.y < water) {
#
for (int i = 0; i < 3; i++) {
#
float fi = float(i);
#
float sp = 50.0 - 11.0 * fi;
#
float xx = p.x + scroll * (12.0 + 20.0 * fi) + fi * 17.0;
#
float cell = floor(xx / sp);
#
float hc = crFHash(vec2(cell, fi * 13.0));
#
float cx = (cell + 0.25 + 0.5 * hc) * sp + sin(t * 0.03 + cell) * 2.0 * crFSat((water - p.y) / 220.0);
#
float wd = 2.0 + 1.6 * fi;
#
float dx = xx - cx;
#
float node = mod(p.y + hc * 40.0, 30.0 - 4.0 * fi);
#
vec3 stalk = mix(mix(hor, top, 0.2), vec3(0.01, 0.035, 0.02), 0.3 + 0.32 * fi);
#
if (hc < 0.35) continue;
#
if (abs(dx) < wd) {
#
c = stalk;
#
if (dx < -wd + 1.0) c = mix(c, base * 0.7 + vec3(0.05), 0.5 - 0.12 * fi);
#
if (node < 1.2) c *= 0.55;
#
} else if (abs(dx) < wd + 11.0 && node > 1.5 && node < 7.0) {
#
float side = sign(dx);
#
float leaf = abs(abs(dx) - wd - (node - 1.5) * 1.9);
#
if (leaf < 1.1 + 0.3 * fi && hc > 0.6) c = stalk * (side > 0.0 ? 0.9 : 1.1);
#
}
#
}
#
} else {
#
float d = p.y - water;
#
vec3 w = mix(hor * 0.55, top * 0.9, crSteps(crFSat(d / 64.0), 5.0, p));
#
float wave = sin(p.x * 0.04 + t * 0.08) * 0.6 + sin(p.x * 0.11 - t * 0.05) * 0.3;
#
float ripple = fract(p.y * 0.42 + wave);
#
float col = exp(-abs(p.x - mc.x) / 9.0) * 0.55 + exp(-abs(p.x) / 26.0) * 0.35;
#
w += moon * col * step(0.55, ripple) * exp(-d / 50.0);
#
w += vec3(0.05, 0.09, 0.08) * step(0.93, ripple);
#
for (int k = 0; k < 6; k++) {
#
float fk = float(k);
#
vec2 pad = vec2((crFHash(vec2(fk, 3.0)) * 2.0 - 1.0) * 230.0, water + 12.0 + crFHash(vec2(fk, 5.0)) * 44.0);
#
vec2 q = (p - pad) / vec2(13.0 + 6.0 * crFHash(vec2(fk, 7.0)), 3.2);
#
if (dot(q, q) < 1.0) w = mix(vec3(0.06, 0.2, 0.1), vec3(0.15, 0.38, 0.2), step(0.0, -q.y));
#
}
#
c = w;
#
c = mix(c, hor, exp(-d / 5.0) * 0.6);
#
}
#
return c;
#
}
#
vec3 crNightVermillon(vec2 p, float t, vec3 base, float scroll) {
#
float h = crFSat((p.y + 150.0) / 230.0);
#
float hq = crSteps(h, 9.0, p);
#
vec3 top = vec3(0.06, 0.012, 0.06) + base * 0.04;
#
vec3 hor = mix(base, vec3(1.0, 0.45, 0.12), 0.45) * 0.62;
#
vec3 c = mix(top, hor, hq * hq);
#
c = crStars(c, p, t, h, 0.99);
#
if (p.y > 20.0) p.x += sin(p.y * 0.35 + t * 0.25) * 0.8;
#
vec2 sc = vec2(0.0, -30.0);
#
float ds = length(p - sc);
#
float sr = 92.0;
#
c += mix(base, vec3(1.0, 0.5, 0.1), 0.5) * 0.55 * exp(-max(ds - sr, 0.0) / 40.0);
#
if (ds < sr) {
#
float u = crFSat((p.y - sc.y + sr) / (2.0 * sr));
#
vec3 sun = mix(vec3(1.0, 0.86, 0.45), vec3(0.95, 0.18, 0.08), crSteps(u, 6.0, p));
#
float y = p.y - sc.y;
#
bool bar = y > 6.0 && fract(y / 13.0 + t * 0.004) < 0.12 + y / 260.0;
#
if (!bar) c = mix(c, sun, 0.95);
#
}
#
for (int i = 0; i < 3; i++) {
#
float fi = float(i);
#
float yc = -96.0 + fi * 34.0;
#
float sx = p.x * 0.012 + scroll * (0.4 + 0.3 * fi) + fi * 2.0;
#
float thick = 2.0 + 3.0 * (0.5 + 0.5 * sin(sx * 3.0));
#
float d = abs(p.y - yc - 3.0 * sin(sx * 2.1));
#
if (d < thick && sin(sx * 1.3 + fi) > -0.2) c = d < 1.0 && p.y < yc ? vec3(1.0, 0.62, 0.3) : vec3(0.34, 0.05, 0.08);
#
}
#
for (int i = 0; i < 2; i++) {
#
float fi = float(i);
#
float x = p.x * (0.009 + 0.006 * fi) + scroll * (0.5 + 0.9 * fi) + fi * 2.7;
#
float m1 = 1.0 - abs(sin(x));
#
float m2 = 1.0 - abs(sin(x * 2.7 + 0.4));
#
float ridge = 44.0 + 30.0 * fi - (70.0 - 16.0 * fi) * (0.7 * m1 * m1 * m1 + 0.25 * m2 * m2);
#
if (p.y > ridge) {
#
vec3 m = mix(vec3(0.16, 0.03, 0.04), vec3(0.03, 0.008, 0.012), 0.4 + 0.5 * fi);
#
if (p.y - ridge < 1.5) m = mix(m, vec3(1.0, 0.45, 0.15), 0.6 - 0.2 * fi);
#
c = m;
#
}
#
}
#
c = crPagoda(c, p, vec3(1.0, 0.4, 0.15));
#
c = mix(c, vec3(0.9, 0.25, 0.06), crSteps(crFSat((p.y - 96.0) / 50.0), 4.0, p) * 0.35);
#
return c;
#
}
#
float crNoise(vec2 p) {
#
vec2 i = floor(p);
#
vec2 f = fract(p);
#
f = f * f * (3.0 - 2.0 * f);
#
float a = crFHash(i);
#
float b = crFHash(i + vec2(1.0, 0.0));
#
float c = crFHash(i + vec2(0.0, 1.0));
#
float d = crFHash(i + vec2(1.0, 1.0));
#
return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
#
}
#
float crFbm(vec2 p) {
#
float v = 0.0;
#
float a = 0.5;
#
for (int i = 0; i < 4; i++) {
#
v += a * crNoise(p);
#
p = p * 2.03 + vec2(17.1, 9.3);
#
a *= 0.5;
#
}
#
return v;
#
}
#
float crSegDist(vec2 p, vec2 a, vec2 b) {
#
vec2 ab = b - a;
#
float u = clamp(dot(p - a, ab) / dot(ab, ab), 0.0, 1.0);
#
return length(p - a - ab * u);
#
}
#
vec2 crConstellation(int i) {
#
if (i == 0) return vec2(-212.0, -118.0);
#
if (i == 1) return vec2(-180.0, -128.0);
#
if (i == 2) return vec2(-150.0, -112.0);
#
if (i == 3) return vec2(-118.0, -126.0);
#
if (i == 4) return vec2(-92.0, -104.0);
#
if (i == 5) return vec2(110.0, -120.0);
#
if (i == 6) return vec2(140.0, -104.0);
#
if (i == 7) return vec2(168.0, -124.0);
#
if (i == 8) return vec2(196.0, -110.0);
#
return vec2(222.0, -128.0);
#
}
#
vec3 crIsland(vec3 c, vec2 p, vec2 at, float w, vec3 base, float t) {
#
vec2 q = p - at - vec2(0.0, sin(t * 0.04 + at.x) * 2.0);
#
bool top = q.y > -3.0 && q.y < 1.0 && abs(q.x) < w;
#
bool rock = q.y >= 1.0 && abs(q.x) < w * (1.0 - q.y / (w * 1.15)) + sin(q.y * 1.3 + at.x) * 1.5;
#
float fall = abs(q.x - w * 0.55);
#
if (fall < 1.6 && q.y > 0.0 && q.y < 70.0) {
#
float drop = fract(q.y * 0.08 - t * 0.12);
#
c = mix(c, mix(vec3(0.75, 0.9, 1.0), base, 0.3), (0.55 + 0.3 * step(0.5, drop)) * (1.0 - q.y / 70.0));
#
}
#
if (top) c = mix(vec3(0.3, 0.5, 0.45), base * 0.8 + vec3(0.1), 0.4);
#
if (rock) c = mix(vec3(0.08, 0.05, 0.14), vec3(0.03, 0.02, 0.06), crFSat(q.y / (w * 0.9)));
#
vec2 m = vec2(abs(q.x + w * 0.1), q.y);
#
bool hall = m.x < w * 0.32 && m.y > -14.0 && m.y < -3.0;
#
bool roof = m.x < w * 0.45 + (m.y + 18.0) * 0.6 && m.y > -20.0 && m.y < -14.0;
#
bool spire = m.x < 1.0 && m.y > -28.0 && m.y < -20.0;
#
if (hall || roof || spire) {
#
c = vec3(0.04, 0.03, 0.08);
#
if (hall && mod(floor(q.x / 3.0), 2.0) < 1.0 && m.y > -11.0 && m.y < -6.0) c = vec3(1.0, 0.8, 0.4);
#
if (roof && m.y < -18.5) c = mix(c, vec3(1.0, 0.85, 0.5), 0.6);
#
}
#
return c;
#
}
#
vec3 crNightCeleste(vec2 p, float t, vec3 base, float scroll, float amt, float warp) {
#
float h = crFSat((p.y + 150.0) / 230.0);
#
float hq = crSteps(h, 9.0, p);
#
vec3 top = vec3(0.008, 0.005, 0.035);
#
vec3 hor = mix(vec3(0.42, 0.14, 0.5), base, 0.4) * 0.55;
#
vec3 c = mix(top, hor, pow(hq, 1.6));
#
float lift = 0.5 + 0.5 * amt;
#
vec2 nq = p * 0.011 + vec2(t * 0.0015, 0.0);
#
float n1 = crFbm(nq + vec2(3.1, 1.7));
#
float n2 = crFbm(nq * 1.7 - vec2(t * 0.002, 4.2));
#
vec3 neb = mix(vec3(0.6, 0.12, 0.72), vec3(0.08, 0.55, 1.0), n2);
#
neb = mix(neb, base, 0.25);
#
float cloud = crSteps(crFSat((n1 - 0.4) * 2.6), 6.0, p);
#
c += neb * cloud * 0.6 * lift * (1.0 - 0.4 * h);
#
c += vec3(1.0, 0.7, 0.9) * crSteps(crFSat((n1 - 0.55) * 4.0) * crFSat((n2 - 0.45) * 3.0), 4.0, p) * 0.35 * lift;
#
vec2 gb = vec2(p.x * 0.92 + p.y * 0.39, -p.x * 0.39 + p.y * 0.92);
#
float band = exp(-(gb.y + 30.0) * (gb.y + 30.0) / 3200.0);
#
c += mix(base, vec3(0.75, 0.65, 1.0), 0.5) * 0.18 * band * (0.6 + 0.4 * crNoise(p * 0.15));
#
c = crStars(c, p, t, h * 0.5, 0.95 - 0.04 * band);
#
vec2 cell = floor(p / 14.0);
#
vec2 glint = cell * 14.0 + 7.0;
#
if (crFHash(cell + 31.0) > 0.975 && p.y < 40.0) {
#
vec2 d = abs(p - glint);
#
float tw = 0.45 + 0.55 * sin(t * 0.22 + crFHash(cell) * 50.0);
#
float spike = max(step(d.x, 0.6) * exp(-d.y / 3.0), step(d.y, 0.6) * exp(-d.x / 3.0));
#
c += mix(vec3(0.85, 0.92, 1.0), base, 0.25) * crSteps(spike * tw + step(max(d.x, d.y), 1.0) * tw, 4.0, p);
#
}
#
float shown = amt * 9.0;
#
for (int i = 0; i < 10; i++) {
#
vec2 a = crConstellation(i);
#
float on = crFSat(shown - float(i) + 1.0);
#
if (on <= 0.0) continue;
#
float ds = length(p - a);
#
if (ds < 2.0) c = mix(c, vec3(1.0, 0.95, 0.8), on);
#
c += mix(vec3(1.0, 0.85, 0.5), base, 0.3) * exp(-ds / 4.0) * 0.4 * on;
#
if (i != 4 && i < 9) {
#
float lineOn = crFSat(shown - float(i));
#
if (lineOn > 0.0 && crSegDist(p, a, crConstellation(i + 1)) < 0.6) c = mix(c, mix(vec3(0.9, 0.8, 0.5), base, 0.3), 0.55 * lineOn);
#
}
#
}
#
float wave = sin(p.x * 0.018 + t * 0.025 + sin(p.x * 0.006 + t * 0.014) * 3.0);
#
float aur = 0.45 + 0.75 * amt;
#
for (int k = 0; k < 2; k++) {
#
float fk = float(k);
#
float curtain = exp(-pow(p.y + 86.0 - 26.0 * fk + 24.0 * wave * (1.0 - 0.4 * fk), 2.0) / (700.0 + 300.0 * fk));
#
float rays = pow(0.5 + 0.5 * sin(p.x * (0.13 + 0.05 * fk) + t * 0.07 + wave * 2.0), 2.0);
#
vec3 col = mix(vec3(0.15, 1.0, 0.7), vec3(0.95, 0.3, 0.95), 0.5 + 0.5 * sin(p.x * 0.008 + t * 0.03 + fk * 2.0));
#
c += mix(col, base, 0.2) * crSteps(curtain * (0.3 + 0.7 * rays), 5.0, p) * 0.55 * aur;
#
}
#
vec2 g = p - vec2(0.0, -34.0);
#
float r = length(g);
#
float ang = atan(g.y, g.x);
#
float spin = scroll * 0.9 + t * 0.004;
#
float arms = pow(0.5 + 0.5 * cos(2.0 * (ang - log(r + 1.0) * 2.3 + spin)), 3.0);
#
vec3 galaxy = mix(vec3(0.4, 0.55, 1.0), vec3(1.0, 0.5, 0.9), crFSat(r / 160.0)) * arms * exp(-r / 125.0) * 1.1;
#
galaxy = mix(galaxy, galaxy * base * 2.0, 0.3);
#
galaxy += vec3(1.0, 0.9, 0.7) * exp(-r / 13.0) * 1.3;
#
c += galaxy * crSteps(crFSat(0.25 + 0.75 * lift), 4.0, p) * (1.0 + 1.6 * warp);
#
for (int k = 0; k < 3; k++) {
#
float fk = float(k);
#
float tilt = 0.35 + fk * 1.05 + t * 0.003 * (mod(fk, 2.0) < 1.0 ? 1.0 : -1.0);
#
vec2 q = vec2(g.x * cos(tilt) + g.y * sin(tilt), -g.x * sin(tilt) + g.y * cos(tilt));
#
float squash = 3.4 + fk * 0.8;
#
float ring = abs(length(vec2(q.x, q.y * squash)) - (132.0 + 22.0 * fk));
#
float around = fract(atan(q.y * squash, q.x) / crF_PI2 * (24.0 + 12.0 * fk) - t * 0.02 * (fk + 1.0));
#
vec3 gold = mix(vec3(1.0, 0.82, 0.4), base, 0.25);
#
if (ring < 1.1) c = mix(c, gold * (0.7 + 0.3 * sin(around * crF_PI2)), 0.8);
#
else if (ring < 3.2 && around < 0.12) c = mix(c, gold, 0.6);
#
}
#
if (warp > 0.0) {
#
float bins = 150.0;
#
float slot = ang / crF_PI2 * bins;
#
float lane = floor(slot);
#
float hs = crFHash(vec2(lane, 77.0));
#
float across = abs(fract(slot) - 0.5) * crF_PI2 * r / bins;
#
float dash = fract(r * (0.012 + 0.01 * hs) + t * (0.12 + 0.12 * hs));
#
if (hs > 0.45 && across < 0.7 && dash < 0.3 && r > 20.0) {
#
c += mix(vec3(0.75, 0.88, 1.0), base, 0.3) * warp * crFSat(r / 120.0) * (1.0 - dash / 0.3);
#
}
#
}
#
c = crIsland(c, p, vec2(-196.0, -78.0), 22.0, base, t);
#
c = crIsland(c, p, vec2(206.0, -100.0), 17.0, base, t);
#
for (int i = 0; i < 3; i++) {
#
float fi = float(i);
#
float x = p.x * (0.02 + 0.008 * fi) + scroll * (0.4 + 0.8 * fi) + fi * 4.1;
#
float puff = abs(sin(x)) * 0.6 + abs(sin(x * 2.3 + 1.1)) * 0.4;
#
float ridge = 52.0 + 26.0 * fi - 18.0 * puff;
#
if (p.y > ridge) {
#
float k = crSteps(crFSat((p.y - ridge) / 26.0), 4.0, p);
#
vec3 lit = mix(vec3(0.85, 0.9, 1.0), mix(base, vec3(1.0, 0.8, 0.55), 0.35), 0.35) * (1.0 - 0.15 * fi);
#
vec3 dark = mix(mix(hor, vec3(0.35, 0.3, 0.6), 0.5), top, 0.2 + 0.2 * fi);
#
c = mix(lit, dark, k);
#
if (p.y - ridge < 1.2) c = mix(c, vec3(1.0, 0.9, 0.6), 0.6 - 0.15 * fi);
#
}
#
}
#
c += mix(base, vec3(1.0, 0.8, 0.5), 0.5) * exp(-max(110.0 - p.y, 0.0) / 30.0) * 0.18;
#
c = crTorii(c, p, base, 68.0);
#
return c;
#
}
#
vec3 crNightAube(vec2 p, float t, vec3 base, float scroll, float amt) {
#
float h = crFSat((p.y + 150.0) / 230.0);
#
float hq = crSteps(h, 10.0, p);
#
float dawn = 0.35 + 0.65 * amt;
#
vec3 top = mix(vec3(0.03, 0.03, 0.12), vec3(0.16, 0.12, 0.36), dawn);
#
vec3 mid = mix(vec3(0.32, 0.12, 0.36), vec3(0.85, 0.38, 0.45), dawn);
#
vec3 hor = mix(vec3(0.75, 0.35, 0.22), vec3(1.0, 0.72, 0.36), dawn);
#
vec3 c = hq < 0.55 ? mix(top, mid, hq / 0.55) : mix(mid, hor, (hq - 0.55) / 0.45);
#
c = crStars(c, p, t, h + 0.6 * amt, 0.965);
#
vec2 sunAt = vec2(0.0, 58.0 - 88.0 * crEaseIO(amt));
#
vec2 s = p - sunAt;
#
float r = length(s);
#
float ang = atan(s.y, s.x);
#
float rays = pow(0.5 + 0.5 * sin(ang * 12.0 + scroll * 0.6 + t * 0.01), 4.0);
#
float rays2 = pow(0.5 + 0.5 * sin(ang * 5.0 - t * 0.006), 6.0);
#
vec3 gold = mix(vec3(1.0, 0.8, 0.42), base, 0.2);
#
c += gold * crSteps(crFSat((rays * 0.7 + rays2 * 0.5) * exp(-r / 150.0)), 5.0, p) * 0.55 * dawn;
#
c += mix(vec3(1.0, 0.55, 0.3), gold, 0.5) * exp(-r / 60.0) * 0.55 * dawn;
#
if (r < 34.0) {
#
float k = crSteps(crFSat(1.0 - r / 34.0), 5.0, p);
#
vec3 disc = mix(vec3(1.0, 0.62, 0.22), vec3(1.0, 0.97, 0.82), k);
#
float band = step(0.5, fract((p.y - sunAt.y) / 7.0 + 0.5)) * step(sunAt.y + 8.0, p.y);
#
c = mix(disc, mix(disc, hor, 0.55), band * 0.6);
#
}
#
for (int k = 0; k < 2; k++) {
#
float fk = float(k);
#
float y0 = -18.0 + 26.0 * fk + 10.0 * sin(p.x * 0.01 + fk * 2.0 + scroll * 0.2);
#
float d = abs(p.y - y0);
#
float len = crFSat(1.0 - abs(p.x + 60.0 - 140.0 * fk) / (210.0 - 40.0 * fk));
#
if (d < 2.5 * len) {
#
vec3 streak = mix(vec3(0.95, 0.5, 0.55), vec3(1.0, 0.85, 0.55), crFSat((y0 - p.y + 2.5) / 5.0));
#
c = mix(c, streak * (0.7 + 0.3 * dawn), 0.75);
#
}
#
}
#
for (int i = 0; i < 5; i++) {
#
float fi = float(i);
#
float x = mod(t * (0.55 + 0.12 * fi) + fi * 113.0, 600.0) - 300.0;
#
float y = -96.0 + 22.0 * fi + 6.0 * sin(t * 0.05 + fi * 2.1);
#
float flap = 3.0 * sin(t * 0.45 + fi * 1.7);
#
vec2 b = p - vec2(x, y);
#
float wing = min(crSegDist(b, vec2(0.0), vec2(-7.0, -3.0 - flap)), crSegDist(b, vec2(0.0), vec2(7.0, -3.0 - flap)));
#
if (wing < 0.9) c = mix(c, vec3(1.0, 0.93, 0.7), 0.85);
#
else c += vec3(1.0, 0.8, 0.45) * exp(-wing / 2.0) * 0.12;
#
}
#
float shaft = pow(0.5 + 0.5 * sin(p.x * 0.045 + t * 0.008), 8.0) * crFSat((p.y - sunAt.y + 20.0) / 120.0);
#
c += gold * crSteps(shaft * 0.35 * dawn, 4.0, p);
#
c = crIsland(c, p, vec2(-198.0, -64.0), 22.0, base, t);
#
c = crIsland(c, p, vec2(204.0, -90.0), 16.0, base, t);
#
for (int i = 0; i < 3; i++) {
#
float fi = float(i);
#
float x = p.x * (0.022 + 0.008 * fi) + scroll * (0.4 + 0.8 * fi) + fi * 3.7;
#
float puff = abs(sin(x)) * 0.6 + abs(sin(x * 2.3 + 1.1)) * 0.4;
#
float ridge = 56.0 + 24.0 * fi - 18.0 * puff;
#
if (p.y > ridge) {
#
float k = crSteps(crFSat((p.y - ridge) / 26.0), 4.0, p);
#
vec3 lit = mix(vec3(1.0, 0.86, 0.66), mix(base, vec3(1.0, 0.7, 0.55), 0.5), 0.3) * (1.0 - 0.12 * fi);
#
vec3 dark = mix(vec3(0.62, 0.32, 0.46), vec3(0.3, 0.16, 0.34), 0.3 + 0.2 * fi);
#
c = mix(lit, dark, k);
#
if (p.y - ridge < 1.2) c = mix(c, vec3(1.0, 0.95, 0.72), 0.7 - 0.15 * fi);
#
}
#
}
#
return c;
#
}
#
vec4 crNight() {
#
vec2 p = floor(csLocal) + 0.5;
#
float t = csFx.y;
#
float reveal = csFx.w;
#
float beat = csFx2.x;
#
float scroll = csFx2.y;
#
int night = int(csFx2.w + 0.5);
#
int theme = min(night, 2);
#
vec3 base = mix(csClip.rgb, csTint2.rgb, csFx.z);
#
vec3 c;
#
if (night == 3) c = crNightAube(p, t, base, scroll, csFx.z);
#
else if (theme == 0) c = crNightJade(p, t, base, scroll);
#
else if (theme == 1) c = crNightVermillon(p, t, base, scroll);
#
else c = crNightCeleste(p, t, base, scroll, csFx.z, csClip.a);
#
if (reveal > 0.0) {
#
vec2 q = p - vec2(0.0, -12.0);
#
float ang = atan(q.y, q.x);
#
float ray = pow(0.5 + 0.5 * sin(ang * 14.0 + t * 0.04), 6.0);
#
c += csTint2.rgb * ray * exp(-length(q) / 170.0) * reveal * 0.6;
#
c += csTint2.rgb * exp(-length(q) / 75.0) * reveal * 0.4;
#
}
#
c *= 1.0 + 0.14 * beat;
#
return vec4(c, 1.0);
#
}
#
vec4 crSeal() {
#
vec2 p = floor(csLocal) + 0.5;
#
float r = length(p);
#
if (r > 82.0) return vec4(0.0);
#
float t = csFx.y;
#
float draw = csFx.z;
#
float wake = csFx.w;
#
vec3 crate = csClip.rgb;
#
float dive = csClip.a;
#
int theme = min(int(csTint2.x + 0.5), 2);
#
float suck = csTint2.y;
#
float turn = fract(atan(p.x, -p.y) / crF_PI2);
#
float top = 0.0;
#
vec3 glow = crate;
#
for (int k = 0; k < 4; k++) {
#
if (csFx2[k] > 0.05) {
#
top = max(top, min(csFx2[k], 1.0));
#
glow = crRAR[k];
#
}
#
}
#
vec3 col;
#
float a;
#
if (r > 64.0) {
#
float g = exp(-(r - 64.0) / 5.0) * (0.25 * wake + 0.55 * top + 0.6 * dive + 0.5 * suck);
#
vec4 out4 = vec4(mix(glow, vec3(1.0), dive), crSteps(crFSat(g), 5.0, p) * draw);
#
if (theme == 1) {
#
float tongue = 64.0 + (6.0 + 8.0 * wake + 4.0 * top) * (0.5 + 0.5 * sin(turn * 24.0 * crF_PI2 + t * 0.35))
#
* (0.6 + 0.4 * sin(turn * 7.0 * crF_PI2 - t * 0.21));
#
if (r < tongue) {
#
float u = (r - 64.0) / max(tongue - 64.0, 1.0);
#
out4 = vec4(mix(vec3(1.0, 0.92, 0.5), mix(vec3(1.0, 0.25, 0.05), glow, 0.4), crSteps(u, 4.0, p)), draw);
#
}
#
} else if (theme == 2) {
#
float orbit = abs(r - 72.0);
#
if (orbit < 0.7) out4 = vec4(mix(vec3(1.0, 0.85, 0.45), glow, 0.3), 0.9 * draw);
#
for (int k = 0; k < 4; k++) {
#
float fk = float(k);
#
float pa = fract(fk * 0.25 + t * (0.006 + 0.002 * fk) + 0.1);
#
vec2 pp = vec2(sin(pa * crF_PI2), -cos(pa * crF_PI2)) * 72.0;
#
if (length(p - pp) < 2.2 + 0.6 * mod(fk, 2.0)) out4 = vec4(mix(vec3(1.0), crRAR[k], 0.5), draw);
#
}
#
if (orbit < 4.0 && orbit > 2.5 && fract(turn * 36.0) < 0.12) out4 = vec4(vec3(0.9, 0.8, 0.5), 0.8 * draw);
#
} else {
#
if (r < 66.5) out4 = vec4(mix(crate * 0.5, vec3(0.75, 1.0, 0.8), 0.25 + 0.4 * wake), draw);
#
}
#
return out4;
#
}
#
if (r < 17.0) {
#
float sh = crSteps(crFSat(0.55 - p.y / 34.0), 4.0, p);
#
col = mix(vec3(0.07, 0.05, 0.09), vec3(0.17, 0.13, 0.2), sh);
#
if (r > 15.0) col = mix(crate, vec3(1.0), 0.25) * (0.45 + 0.55 * wake);
#
col += crate * exp(-r / 6.0) * (wake + suck) * 0.9;
#
return vec4(mix(col, vec3(1.0), dive * 0.7), crFSat(draw * 3.0));
#
}
#
float spokes = theme == 1 ? 16.0 : (theme == 2 ? 12.0 : 8.0);
#
float spoke = abs(fract(turn * spokes + 0.5) - 0.5) / spokes * crF_PI2 * r;
#
if (theme == 0) {
#
vec2 hq = vec2(p.x / 5.0 + 0.5 * mod(floor(p.y / 5.0), 2.0), p.y / 5.0);
#
float grain = length(fract(hq) - 0.5);
#
col = mix(crate * 0.3 + vec3(0.02, 0.06, 0.04), crate * 0.55 + vec3(0.06, 0.12, 0.08), step(grain, 0.3));
#
a = 0.92 * draw;
#
} else if (theme == 1) {
#
col = vec3(0.22, 0.03, 0.035);
#
a = 0.88 * draw;
#
if (spoke < 0.7) {
#
col = mix(vec3(0.95, 0.7, 0.25), crate, 0.25);
#
a = draw;
#
}
#
} else {
#
col = vec3(0.03, 0.035, 0.1);
#
a = 0.72 * draw;
#
if (crFHash(floor(p)) > 0.96) col += vec3(0.6, 0.7, 0.9);
#
if (spoke < 0.55) {
#
col = mix(vec3(0.95, 0.82, 0.45), crate, 0.3 + 0.3 * wake);
#
a = 0.9 * draw;
#
}
#
}
#
int k = int(floor((r - 20.0) / 12.0));
#
float rr = r - 20.0 - 12.0 * float(k);
#
if (k >= 0 && k < 4 && rr < 7.0 && fract(turn - float(k) * 0.25 + 1.0) <= draw) {
#
float fk = float(k);
#
float lit = csFx2[k];
#
float dir = mod(fk, 2.0) < 1.0 ? 1.0 : -1.0;
#
float ak = fract(turn + dir * t * (0.004 + 0.002 * fk) + fk * 0.13);
#
float seg = ak * (12.0 + 6.0 * fk);
#
float si = floor(seg);
#
float sf = fract(seg);
#
bool edge = rr < 1.0 || rr >= 6.0;
#
float bits = crFHash(vec2(si, fk * 7.0 + 1.0));
#
float cell = floor((sf - 0.15) / 0.175) * 5.0 + floor(rr - 1.5);
#
bool rune = sf > 0.15 && sf < 0.85 && rr >= 1.5 && rr < 5.5 && fract(bits * (3.0 + cell) * 7.13) > 0.42;
#
vec3 rc = crRAR[k];
#
vec3 stone = theme == 0 ? crate * 0.22 + vec3(0.03, 0.06, 0.04) : (theme == 1 ? vec3(0.16, 0.03, 0.03) : vec3(0.1, 0.1, 0.17));
#
vec3 rim = theme == 1 || theme == 2 ? vec3(0.8, 0.6, 0.25) : mix(stone, crate, 0.5);
#
vec3 off = edge ? rim : (rune ? stone * 2.2 : stone);
#
vec3 on = edge ? rc : (rune ? mix(rc, vec3(1.0), 0.6) : rc * 0.4);
#
col = mix(off, on, min(lit, 1.0));
#
col = mix(col, vec3(1.0), crFSat(max(lit - 1.0, 0.0) * 0.6));
#
col += rc * min(lit, 1.0) * 0.3 * pow(0.5 + 0.5 * sin(turn * crF_PI2 * 2.0 - t * 0.3 + fk), 8.0);
#
a = 1.0;
#
}
#
col = mix(col, glow, suck * 0.3);
#
return vec4(mix(col, vec3(1.0), dive * 0.6), a);
#
}
#
vec4 crInk() {
#
vec2 p = floor(csLocal / 2.0) * 2.0 + 1.0;
#
float bristle = (crFHash(vec2(floor(p.y / 3.0), 3.0)) - 0.5) * 26.0 + sin(p.y * 0.05) * 14.0;
#
float d = p.x + 0.42 * p.y + bristle;
#
float ein = mix(-720.0, 720.0, crEaseIO(csFx.y));
#
float eout = mix(-720.0, 720.0, crEaseIO(csFx.z));
#
if (d <= ein && d >= eout) return vec4(0.0);
#
float near = min(abs(d - ein), abs(d - eout));
#
vec3 ink = vec3(0.03, 0.022, 0.04);
#
if (near < 12.0) {
#
if (crFHash(vec2(floor(p.y / 2.0), floor(near / 4.0) + floor(csFx.w))) > 0.72) return vec4(0.0);
#
ink = mix(vec3(0.15, 0.11, 0.17), ink, near / 12.0);
#
}
#
ink += csTint2.rgb * 0.1 * exp(-near / 8.0);
#
return vec4(ink, 1.0);
#
}
#
const float irT_CLOSE = 8.0;
#
const float irT_OPEN = 9.0;
#
const float irT_LEAD = 20.0;
#
const float irT_FLASH = 2.0;
#
const float irCELLS = 72.0;
#
float irHash(vec2 p) {
#
return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
#
}
#
vec4 irIris(vec2 g, float t, float opening, vec2 scr) {
#
float k;
#
if (opening < 0.5) {
#
if (t < 0.0) return vec4(0.0);
#
float c = clamp(t / irT_CLOSE, 0.0, 1.0);
#
k = c * c * (1.6 - 0.6 * c);
#
} else {
#
float o = clamp(t / irT_OPEN, 0.0, 1.0);
#
float y = 1.0 - o;
#
k = y * y * y;
#
}
#
if (k <= 0.0) return vec4(0.0);
#
float cell = max(2.0, floor(scr.y / irCELLS + 0.5));
#
float span = 0.5 * length(scr);
#
vec2 ci = floor((g - scr * 0.5) / cell);
#
vec2 q = (ci + 0.5) * cell / span;
#
float r = 1.05 * (1.0 - k) * span / cell;
#
float band = length(q) * span / cell - r;
#
float h = irHash(ci);
#
float h2 = irHash(ci + floor(t * 0.7) * 7.13);
#
vec3 rim = mix(vec3(0.62, 0.25, 1.0), vec3(0.88, 0.72, 1.0), step(0.5, h2));
#
float edge = min(1.0, r);
#
if (band >= 0.0) {
#
vec3 obs = mix(vec3(0.05, 0.035, 0.08), vec3(0.10, 0.07, 0.15), step(0.6, h));
#
obs = mix(obs, vec3(0.38, 0.12, 0.62), step(0.97, h) * (0.5 + 0.5 * sin(t * 0.4 + h * 20.0)));
#
obs = mix(obs, vec3(0.30, 0.10, 0.52), 0.45 * exp(-band / 2.5) * step(edge, band) * edge);
#
vec3 col = band < edge ? rim : (band < 2.0 * edge ? mix(rim, obs, 0.55) : obs);
#
vec2 cc = ci + 0.5;
#
if (opening < 0.5) {
#
float u = (t - irT_CLOSE + 0.5) / irT_FLASH;
#
float plus = max(step(abs(cc.x), 0.6) * step(abs(cc.y), 2.6), step(abs(cc.y), 0.6) * step(abs(cc.x), 2.6));
#
col = mix(col, vec3(0.94, 0.86, 1.0), plus * step(0.0, u) * clamp(2.0 - 2.0 * u, 0.0, 1.0));
#
} else {
#
float o = clamp(t / irT_OPEN, 0.0, 1.0);
#
float ring = step(abs(band - 2.0 - 9.0 * o), 0.7) * step(0.0, t) * pow(1.0 - o, 1.5);
#
col = mix(col, rim, ring);
#
}
#
return vec4(col, 1.0);
#
}
#
if (k < 0.999 && -band < 6.0 && h2 < 0.35 * exp(band / 1.5)) return vec4(rim, 0.9);
#
return vec4(0.0);
#
}
#
const float fsT_TOTAL = 110.0;
#
const float fsT_LEAD = 20.0;
#
const float fsT_IN = 6.0;
#
const float fsT_CASE = 6.0;
#
const float fsT_CASE_IN = 10.0;
#
const float fsT_FADE = 16.0;
#
const float fsCASE = 48.0;
#
const float fsICON = 16.0;
#
const float fsCASE_SCALE = 2.0;
#
const float fsICON_SCALE = 4.0;
#
const float fsCASE_Y = -40.0;
#
const float fsSPIN = 0.09;
#
float fsBack(float x) {
#
float y = x - 1.0;
#
return 1.0 + 2.70158 * y * y * y + 1.70158 * y * y;
#
}
#
float fsHash(vec2 p) {
#
return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
#
}
#
vec4 fsReveal(vec2 g, float t, float s, vec2 scr) {
#
if (t < 0.0 || t >= fsT_TOTAL) return vec4(0.0);
#
float cell = max(1.0, 2.0 * s);
#
vec2 q = (floor(g / cell) + 0.5) * cell;
#
vec2 c = scr * 0.5 + vec2(0.0, fsCASE_Y * s);
#
vec2 d = (q - c) / (0.5 * scr.y);
#
float r = length(d);
#
float a = atan(d.y, d.x);
#
float live = clamp(t / fsT_IN, 0.0, 1.0) * (1.0 - clamp((t - (fsT_TOTAL - fsT_FADE)) / fsT_FADE, 0.0, 1.0));
#
float lit = clamp((t - fsT_CASE) / 8.0, 0.0, 1.0);
#
float veil = (0.84 + 0.12 * smoothstep(0.5, 1.7, r)) * live;
#
float r1 = pow(0.5 + 0.5 * cos(14.0 * (a - t * 0.025)), 5.0);
#
float r2 = pow(0.5 + 0.5 * cos(10.0 * (a + t * 0.018) + 1.3), 5.0);
#
float fall = exp(-r * 1.5) * smoothstep(0.06, 0.2, r);
#
float rayA = clamp((r1 * 0.95 + r2 * 0.8) * fall, 0.0, 1.0) * live * lit;
#
vec3 rays = (vec3(1.0, 0.33, 0.33) * r1 * 0.8 + vec3(1.0, 0.33, 1.0) * r2 * 0.65) / max(0.001, r1 * 0.8 + r2 * 0.65);
#
float glowA = exp(-pow(r / 0.24, 2.0)) * 0.8 * live * lit;
#
vec3 glow = mix(vec3(1.0, 0.42, 0.72), vec3(1.0, 0.96, 0.88), exp(-pow(r / 0.09, 2.0)));
#
float ring = (t - fsT_CASE) / 12.0;
#
float ringA = (ring > 0.0 && ring < 1.0) ? exp(-pow((r - ring * 1.5) / 0.035, 2.0)) * (1.0 - ring) : 0.0;
#
float flash = (t >= fsT_CASE && t < fsT_CASE + 5.0) ? (1.0 - (t - fsT_CASE) / 5.0) * 0.75 : 0.0;
#
float h = fsHash(floor(g / (2.0 * cell)));
#
float tw = step(0.982, h) * pow(0.5 + 0.5 * sin(t * 0.45 + h * 40.0), 6.0) * live * lit;
#
vec3 premul = vec3(0.045, 0.012, 0.06) * veil * (1.0 - clamp(rayA + glowA, 0.0, 1.0))
#
+ rays * rayA + glow * glowA + vec3(1.0) * (ringA + flash) + vec3(1.0, 0.9, 0.96) * tw;
#
float alpha = clamp(max(veil, rayA + glowA + ringA + flash + tw), 0.0, 1.0);
#
if (alpha <= 0.0) return vec4(0.0);
#
return vec4(clamp(premul / alpha, 0.0, 1.0), alpha);
#
}
#
const float spIN = 16.0;
#
const float spOUT = 9.0;
#
const float spD_BIG = 20000.0;
#
const float spD_BIG_OUT = 25000.0;
#
const float spD_SMALL = 30000.0;
#
const float spD_SMALL_OUT = 35000.0;
#
const float spD_MID = 40000.0;
#
const float spD_MID_OUT = 45000.0;
#
const float spD_PLATE = 22000.0;
#
const float spBIG = 3.0;
#
const float spMID = 2.0;
#
const float spSMALL = 1.0;
#
const float spY = 0.22;
#
const float spGAP = 5.0;
#
const float spPADX = 14.0;
#
const float spPADT = 8.0;
#
const float spPADB = 8.0;
#
const float spSPRITE_W = 48.0;
#
const float spSPRITE_H = 32.0;
#
const float spEDGE = 8.0;
#
const float spMARGIN = 40.0;
#
const float spSHINE = 70.0;
#
const float spSLAM = 2.6;
#
const float spDAMP = 0.85;
#
const float spFREQ = 1.5;
#
const float spSTAG = 0.06;
#
const float spSTAG_SUB = 0.035;
#
const float spSTAG_MAX = 4.5;
#
const float spSUB_AT = 6.0;
#
const vec3 spSHADOW = vec3(10.0, 6.0, 3.0) / 255.0;
#
const vec3 spLIGHT[5] = vec3[5](vec3(1.0, 0.84, 0.42), vec3(0.49, 1.0, 0.69), vec3(1.0, 0.42, 0.35),
#
vec3(0.84, 0.61, 1.0), vec3(0.56, 0.78, 1.0));
#
const float spHALO[5] = float[5](0.3, 0.0, 0.0, 0.3, 0.0);
#
float spHash(vec2 p) {
#
return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
#
}
#
float spPiece(float q, float s, float e, float sprite) {
#
if (q < e) return q;
#
if (q >= s - e) return sprite - (s - q);
#
return e + mod(q - e, sprite - 2.0 * e);
#
}
#
vec4 spPlate(vec2 c, vec4 r, vec4 fx, vec4 uv) {
#
vec2 p = floor(c);
#
float t = fx.x;
#
bool going = fx.y > 0.5;
#
int tone = int(fx.z + 0.5);
#
float clock = fx.w;
#
vec3 light = spLIGHT[tone];
#
vec2 mid = (r.xy + r.zw) * 0.5;
#
vec2 s = r.zw - r.xy;
#
float sheenX = (t < spIN - 0.01 && !going ? (t - 7.0) * 30.0 - 130.0 : mod(clock, spSHINE) * 30.0 - 130.0) * spBIG;
#
if (p.x >= r.x && p.y >= r.y && p.x < r.z && p.y < r.w) {
#
vec2 q = p - r.xy;
#
vec2 tx = vec2(spPiece(q.x, s.x, spEDGE, spSPRITE_W), spPiece(q.y, s.y, spEDGE, spSPRITE_H));
#
vec4 col = textureLod(Sampler0, uv.xy + (tx + 0.5) / vec2(spSPRITE_W, spSPRITE_H) * uv.zw, 0.0);
#
if (col.a <= 0.0) return vec4(0.0);
#
float flash = going ? clamp(1.0 - t / 3.0, 0.0, 1.0) * 0.5 : clamp(1.0 - (t - 1.0) / 6.0, 0.0, 1.0) * step(0.5, t);
#
col.rgb = mix(col.rgb, mix(light, vec3(1.0), 0.5), floor(flash * 4.0) / 4.0 * 0.85);
#
float d = (p.x - mid.x) - (p.y - mid.y) * 0.5 - sheenX;
#
float band = abs(d) < 2.0 ? 0.45 : (abs(d) < 5.0 ? 0.18 : 0.0);
#
col.rgb = mix(col.rgb, vec3(1.0, 0.97, 0.88), band);
#
return col;
#
}
#
if (going) return vec4(0.0);
#
vec2 out2 = max(max(r.xy - p, p - r.zw + 1.0), 0.0);
#
float far = length(out2) / spMARGIN;
#
if (far >= 1.0) return vec4(0.0);
#
float burst = clamp((t - 1.0) / 2.0, 0.0, 1.0) * (1.0 - clamp((t - 5.0) / 9.0, 0.0, 1.0));
#
float keep = spHALO[tone];
#
float glow = max(burst, keep);
#
if (glow <= 0.0) return vec4(0.0);
#
vec2 v = (p - mid) / vec2(s.x * 0.5 + spMARGIN, s.y * 0.5 + spMARGIN);
#
float ang = atan(v.y, v.x) / 6.2831853;
#
float ray = step(0.55, fract(ang * 18.0 + clock * 0.004 + t * 0.03));
#
float a = ray * (1.0 - far) * (1.0 - far) * glow;
#
vec2 cell = floor(p / 3.0);
#
float h = spHash(cell);
#
float tw = fract(h * 13.7 + clock * 0.045);
#
float spark = (h > 0.9 && tw < 0.18 && far < 0.7) ? (1.0 - tw / 0.18) : 0.0;
#
vec2 inCell = p - cell * 3.0;
#
spark *= (inCell.x == 1.0 || inCell.y == 1.0) ? 1.0 : 0.0;
#
spark *= max(burst * 1.5, keep * 2.0);
#
a = floor(a * 4.0) / 4.0 * 0.7;
#
if (spark > 0.25) return vec4(mix(light, vec3(1.0), 0.6), min(1.0, spark));
#
return vec4(light, a);
#
}
#
const float rbD_WORDS = 34000.0;
#
const float rbD_PLATE = 36000.0;
#
const float rbD_SCREEN = 55000.0;
#
const float rbD_SCREEN_PLATE = 39500.0;
#
const float rbLIFT = 48.0;
#
const float rbD_WORDS_LOW = 33000.0;
#
const float rbD_PLATE_LOW = 35500.0;
#
const float rbLIFT_LOW = 4.0;
#
const float rbWRAP = 125.0;
#
const float rbEARLY = 16.0;
#
const float rbIN = 10.0;
#
const float rbPULSE = 9.0;
#
const float rbOUT = 7.0;
#
const float rbFADE = 20.0;
#
const float rbSHOW = 60.0;
#
const float rbSPRITE_W = 40.0;
#
const float rbSPRITE_H = 20.0;
#
const float rbLEFT = 20.0;
#
const float rbEDGE = 7.0;
#
const float rbGAP = 3.0;
#
const float rbPADX = 9.0;
#
const float rbPADT = 6.0;
#
const float rbSHIFT = 7.0;
#
const float rbMARGIN = 14.0;
#
const float rbSHINE = 80.0;
#
vec4 rbPlate(vec2 c, vec4 r, vec4 fx, vec4 uv, float clock, bool going) {
#
vec2 p = floor(c);
#
float t = fx.x;
#
bool pulse = fx.y > 0.5;
#
int tone = int(fx.z + 0.5);
#
vec3 light = spLIGHT[tone];
#
vec2 s = r.zw - r.xy;
#
vec2 mid = (r.xy + r.zw) * 0.5;
#
if (p.x >= r.x && p.y >= r.y && p.x < r.z && p.y < r.w) {
#
vec2 q = p - r.xy;
#
float tx = q.x < rbLEFT ? q.x
#
: (q.x >= s.x - rbEDGE ? rbSPRITE_W - (s.x - q.x) : rbLEFT + mod(q.x - rbLEFT, rbSPRITE_W - rbLEFT - rbEDGE));
#
vec4 col = textureLod(Sampler0, uv.xy + (vec2(tx, q.y) + 0.5) / vec2(rbSPRITE_W, rbSPRITE_H) * uv.zw, 0.0);
#
if (col.a <= 0.0) return vec4(0.0);
#
float flash = going ? 0.0 : (pulse ? clamp(1.0 - t / 4.0, 0.0, 1.0) * 0.6
#
: clamp(1.0 - (t - 1.0) / 5.0, 0.0, 1.0) * step(0.5, t));
#
col.rgb = mix(col.rgb, mix(light, vec3(1.0), 0.5), floor(flash * 4.0) / 4.0 * 0.6);
#
float d = (p.x - mid.x) - (p.y - mid.y) * 0.5 - fx.w;
#
float band = going ? 0.0 : (abs(d) < 2.0 ? 0.4 : (abs(d) < 4.0 ? 0.15 : 0.0));
#
col.rgb = mix(col.rgb, vec3(1.0, 0.97, 0.88), band);
#
return col;
#
}
#
if (going) return vec4(0.0);
#
float far = length(max(max(r.xy - p, p - r.zw + 1.0), 0.0));
#
if (far >= rbMARGIN) return vec4(0.0);
#
float life = pulse ? 5.0 : 7.0;
#
float ring = pulse ? t * 2.4 : (t - 1.0) * 2.6;
#
float a = (t > 0.0 && t < life && abs(far - ring) < 1.0) ? (1.0 - t / life) : 0.0;
#
float burst = clamp(t / 2.0, 0.0, 1.0) * (1.0 - clamp((t - 2.0) / 8.0, 0.0, 1.0));
#
float keep = tone == 3 ? 0.35 : (tone == 0 ? 0.15 : 0.0);
#
vec2 cell = floor(p / 3.0);
#
float h = spHash(cell);
#
float tw = fract(h * 13.7 + clock * 0.05);
#
float spark = (h > 0.88 && tw < 0.2 && far < rbMARGIN * 0.75) ? (1.0 - tw / 0.2) : 0.0;
#
vec2 inCell = p - cell * 3.0;
#
spark *= (inCell.x == 1.0 || inCell.y == 1.0) ? 1.0 : 0.0;
#
spark *= max(pulse ? 0.0 : burst * 1.4, keep * 2.0);
#
if (spark > 0.25) return vec4(mix(light, vec3(1.0), 0.6), min(1.0, spark));
#
a = floor(a * 4.0) / 4.0 * 0.85;
#
return vec4(mix(light, vec3(1.0), 0.3), a);
#
}
#
#endif
void main() {
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif
#if defined(IS_SEE_THROUGH) && defined(SB_MOJ)
vec4 color = texColor * vertexColor;
#else
vec4 color = texColor * vertexColor * ColorModulator;
#endif
#ifdef SB_OURS
if (gsOn > 0.5) {
#
if (gsOn < 1.5) {
#
color = gsGlow(gsAt(gsLocal - vec2(0.0, gsP1.y)), gsLocal);
#
} else if (gsOn < 2.5) {
#
vec2 gsQ = gsLocal;
#
if ((int(gsP0.x) & 15) == 5) {
#
float gsRow = floor(gsQ.y);
#
float gsK = gsRow < gsP1.x ? 0.0 : (gsRow - gsP1.x) / max(gsSz.y - gsP1.x, 1.0);
#
gsQ.x -= floor(gsP0.y * sin(gsP1.z * 6.2832 / gsP0.z - gsRow * 0.16 + gsP0.w) * gsK * 1.4 + 0.5);
#
}
#
vec4 gsC = gsAt(gsQ);
#
if (gsClip.z > gsClip.x && (gsCanvas.x < gsClip.x || gsCanvas.x >= gsClip.z || gsCanvas.y < gsClip.y || gsCanvas.y >= gsClip.w)) {
#
gsC.a = 0.0;
#
}
#
color = vec4(gsC.rgb, gsC.a * gsP1.y);
#
}
#
}
#
if (vtA.x > 0.5) {
#
float vtOn = vtA.x;
#
vec2 vtLocal = vtLC.xy;
#
vec2 vtCanvas = vtLC.zw;
#
vec4 vtCol;
#
vec2 vtSp = vtCanvas - vtDOOR_C;
#
if (vtOn > 3.5) {
#
vtCol = vec4(1.0);
#
} else if (vtOn > 2.5) {
#
vtCol = vtWall(vtCanvas);
#
} else if (vtOn > 1.5) {
#
vtCol = vtOnPlane(vtCanvas);
#
vtSp = vtUnproject(vtCanvas) - vec2(vtDOOR_C.x - vtHINGE_X, 0.0);
#
} else {
#
vtCol = vtSample(vtLocal);
#
}
#
vec3 vtRgb = (vtOn > 2.5 && vtOn < 3.5) ? vtCol.rgb : vtCol.rgb * vtTint.rgb;
#
if (vtFx.z > 0.0 && vtOn < 2.5) {
#
float vtLum = dot(vtCol.rgb, vec3(0.3, 0.55, 0.15));
#
vtRgb = mix(vtRgb, vec3(1.0, 0.97, 0.88), vtSheenAt(vtSp) * smoothstep(0.3, 0.7, vtLum));
#
}
#
float vtAl = vtCol.a * vtTint.a;
#
if (vtPiv.w > 0.5) {
#
vtAl *= vtCanvas.y > vtFLOOR_Y ? 0.34 * exp(-(vtCanvas.y - vtFLOOR_Y) / 24.0) : 0.0;
#
}
#
if (vtAl < 0.1) {
#
vtAl = (vtCol.a > 0.02 && vtAl * 10.0 > vtDither(gl_FragCoord.xy)) ? 0.1 : 0.0;
#
}
#
color = vec4(vtRgb, vtAl);
#
}
#
if (gsOn > 2.5 && gsOn < 3.5) {
#
int jnState = int(gsP0.x + 0.5);
#
if (jnState == 5) {
#
color = jnBarPaint(gsLocal, gsP0.y, gsP0.z, gsP0.w);
#
} else if (jnState == 3 || jnState == 7) {
#
color = jnCardPaint(gsLocal, jnState, int(gsP1.y + 0.5), gsP0.z, gsP0.w);
#
} else {
#
color = jnCellPaint(gsLocal, jnState, int(gsP1.y + 0.5), gsP0.z, gsP0.w, gsP1.x);
#
}
#
}
#
if (csOn > 0.5 && csOn < 2.5) {
#
vec4 csC;
#
if (csFx.x > 3.5) csC = csCrisp(csLocal);
#
else if (csFx.x > 2.5) csC = csBlurX(csLocal, csFx.y);
#
else if (csFx.x > 1.5) csC = csStrip(csLocal, csFx.y, csFx2.x);
#
else if (csFx.x > 0.5) csC = csSmooth(csLocal);
#
else csC = csAt(csLocal * csSz / csDisp);
#
vec3 csRgb = csC.a > 0.0 ? csC.rgb / csC.a : vec3(0.0);
#
vec3 csT = csFx.z > 0.5 ? mix(csTint.rgb, csTint2.rgb, clamp(csLocal.y / csDisp.y, 0.0, 1.0)) : csTint.rgb;
#
csRgb *= csT;
#
float csLum = dot(csRgb, vec3(0.3, 0.55, 0.15));
#
csRgb = mix(csRgb, vec3(1.0), csFx.w * smoothstep(0.08, 0.45, csLum));
#
if (csFx2.w > 0.5) {
#
float csBand = csLocal.x + csLocal.y * 0.6 - csFx2.z;
#
csRgb = mix(csRgb, vec3(1.0), exp(-csBand * csBand / 14.0) * 0.65);
#
}
#
float csEdge = min(min(csCanvas.x - csClip.x, csClip.z - csCanvas.x), min(csCanvas.y - csClip.y, csClip.w - csCanvas.y));
#
float csA = csC.a * csTint.a * clamp(csEdge / 5.0, 0.0, 1.0);
#
color = vec4(csRgb, csA);
#
}
#
if (csOn > 2.5 && csOn < 3.5) {
#
vec4 gbCol;
#
if (csFx.x < 1.5) gbCol = gbDisc();
#
else if (csFx.x < 2.5) gbCol = gbBackdrop();
#
else if (csFx.x < 3.5) gbCol = gbTrail();
#
else gbCol = gbCrtMask();
#
color = vec4(gbCol.rgb, gbCol.a * csTint.a);
#
}
#
if (csOn > 3.5 && csOn < 4.5) {
#
vec4 crCol;
#
if (csFx.x < 1.5) crCol = crNight();
#
else if (csFx.x < 2.5) crCol = crSeal();
#
else crCol = crInk();
#
color = vec4(crCol.rgb, crCol.a * csTint.a);
#
}
#
if (csOn > 4.5 && csOn < 5.5) {
#
vec4 irCol = irIris(csCanvas, csFx.x, csFx.y, csFx.zw);
#
color = vec4(irCol.rgb, irCol.a * csTint.a);
#
}
#
if (csOn > 5.5 && csOn < 6.5) {
#
vec4 fsCol = fsReveal(csCanvas, csFx.x, csFx.y, csFx.zw);
#
color = vec4(fsCol.rgb, fsCol.a * csTint.a);
#
}
#
if (csOn > 6.5 && csOn < 7.5) {
#
vec4 spCol = spPlate(csCanvas, csRect, csFx, csFx2);
#
color = vec4(spCol.rgb, spCol.a * csTint.a);
#
}
#
if (csOn > 7.5 && csOn < 8.5) {
#
vec4 rbCol = rbPlate(csCanvas, csRect, csFx, csFx2, csTint.y, csTint.x > 0.0);
#
color = vec4(rbCol.rgb, rbCol.a * csTint.a);
#
}
#
#endif
if (color.a < 0.1) {discard;}
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
color = sampleColorForAccumulation(color);
#endif
#if defined(IS_SEE_THROUGH) && defined(SB_MOJ)
fragColor = color * ColorModulator;
#elif defined(IS_SEE_THROUGH) || defined(IS_GUI)
fragColor = color;
#else
#ifdef OIT_ACCUMULATE
vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
vec4 fogColor = FogColor;
#endif
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
#endif
}