#version 330

// Written by .claude/scripts/gen-portal-panorama.py: never hand-edit, rerun.
// Vanilla's, plus the vector from the eye to the vertex in world axes
// (Position is camera-relative and unrotated, as the fog reads it).

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#else
#include <minecraft:fog.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:dynamictransforms.glsl>
#endif

SB_LOC(0) in vec3 Position;

SB_LOC(0) out vec4 texProj0;
SB_LOC(1) out float sphericalVertexDistance;
SB_LOC(2) out float cylindricalVertexDistance;
SB_LOC(3) out vec3 eyeToPixel;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    texProj0 = projection_from_position(gl_Position);
    eyeToPixel = Position;
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}
