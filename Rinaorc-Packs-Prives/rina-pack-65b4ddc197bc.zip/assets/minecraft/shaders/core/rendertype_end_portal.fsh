#version 330

// Written by .claude/scripts/gen-portal-panorama.py: never hand-edit, rerun.
// End gateways (PORTAL_LAYERS 16, the rune portals' discs): a panorama, a cube
// of six faces in Sampler1, looked up along the eye's direction turned into
// its frame: the hub's in a disc across x (the island's portal), the island's
// in a disc across z (the hub's and the realms'); a haze and a few of the
// vanilla star layers over it. End portals (15): the vanilla stars, their
// tile read from its corner of the same texture.

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:matrix.glsl>
#moj_import <minecraft:globals.glsl>
#else
#include <minecraft:fog.glsl>
#include <minecraft:matrix.glsl>
#include <minecraft:globals.glsl>
#endif

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

SB_LOC(0) in vec4 texProj0;
SB_LOC(1) in float sphericalVertexDistance;
SB_LOC(2) in float cylindricalVertexDistance;
SB_LOC(3) in vec3 eyeToPixel;

const vec3[] COLORS = vec3[](
    vec3(0.022087, 0.098399, 0.110818),
    vec3(0.011892, 0.095924, 0.089485),
    vec3(0.027636, 0.101689, 0.100326),
    vec3(0.046564, 0.109883, 0.114838),
    vec3(0.064901, 0.117696, 0.097189),
    vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380),
    vec3(0.097489, 0.154120, 0.091064),
    vec3(0.106152, 0.131144, 0.195191),
    vec3(0.097721, 0.110188, 0.187229),
    vec3(0.133516, 0.138278, 0.148582),
    vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696),
    vec3(0.047281, 0.315338, 0.321970),
    vec3(0.204675, 0.390010, 0.302066),
    vec3(0.080955, 0.314821, 0.661491)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

const vec2 GRID = vec2(4.0, 3.0);
const vec2 STARS_ORIGIN = vec2(0.25000000, 0.33333333);
const vec2 STARS_SPAN = vec2(0.12500000, 0.16666667);
const float FACE_TEXELS = 512.0;
const float ISLAND_ROWS = 1.50000000;

// The eye's direction into a panorama's frame (its north: where one faces on
// arrival), by which way it looks through the disc: across x (the island's
// portal) from the east or the west, across z (the hub's, the realms') from
// the north or the south. n: the face's normal, any sign.
vec3 portal_frame(vec3 d, vec3 n) {
    if (n.x >= n.z) {
        return d.x < 0.0 ? vec3(-d.z, d.y, d.x) : vec3(d.z, d.y, -d.x);
    }
    return d.z > 0.0 ? vec3(-d.x, d.y, -d.z) : d;
}

// Where along p a panorama's block is read, in faces: the face's place (x, y)
// plus (u, v) times its size (sides 1, sky and ground 0.5), and that size.
vec3 portal_cube(vec3 p) {
    vec3 a = abs(p);
    vec3 fwd; vec3 right; vec3 up; vec3 rect;
    if (a.x >= a.y && a.x >= a.z) {
        if (p.x > 0.0) { fwd = vec3(1, 0, 0); right = vec3(0, 0, 1); up = vec3(0, 1, 0); rect = vec3(0.0, 0.0, 1.0); }
        else { fwd = vec3(-1, 0, 0); right = vec3(0, 0, -1); up = vec3(0, 1, 0); rect = vec3(1.0, 0.0, 1.0); }
    } else if (a.y >= a.z) {
        if (p.y > 0.0) { fwd = vec3(0, 1, 0); right = vec3(1, 0, 0); up = vec3(0, 0, -1); rect = vec3(0.0, 1.0, 0.5); }
        else { fwd = vec3(0, -1, 0); right = vec3(1, 0, 0); up = vec3(0, 0, 1); rect = vec3(0.5, 1.0, 0.5); }
    } else {
        if (p.z > 0.0) { fwd = vec3(0, 0, 1); right = vec3(-1, 0, 0); up = vec3(0, 1, 0); rect = vec3(2.0, 0.0, 1.0); }
        else { fwd = vec3(0, 0, -1); right = vec3(1, 0, 0); up = vec3(0, 1, 0); rect = vec3(3.0, 0.0, 1.0); }
    }
    vec3 q = p / dot(p, fwd);
    vec2 uv = vec2((dot(q, right) + 1.0) * 0.5, (1.0 - dot(q, up)) * 0.5);
    return vec3(rect.xy + uv * rect.z, rect.z);
}

mat4 end_portal_layer(float layer) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

vec3 stars(float layer) {
    vec4 p = texProj0 * end_portal_layer(layer);
    vec2 uv = fract(p.xy / p.w);
    return texture(Sampler1, STARS_ORIGIN + uv * STARS_SPAN).rgb;
}

vec3 panorama(vec3 p, float rows) {
    vec3 c = portal_cube(p);
    // Half a texel in from the face's edges: never a neighbour's.
    vec2 inside = fract(c.xy / c.z);
    vec2 base = floor(c.xy / c.z) * c.z;
    float margin = 0.5 / (FACE_TEXELS * c.z);
    vec2 at = base + clamp(inside, margin, 1.0 - margin) * c.z;
    return texture(Sampler1, (at + vec2(0.0, rows)) / GRID).rgb;
}

SB_LOC(0) out vec4 fragColor;

void main() {
#if PORTAL_LAYERS == 16
    vec3 d = normalize(eyeToPixel);
    vec3 n = abs(cross(dFdx(eyeToPixel), dFdy(eyeToPixel)));
    float rows = n.z > n.x && n.z > n.y ? ISLAND_ROWS : 0.0;
    vec3 p = portal_frame(d, n);
    // A slow haze, so it reads as a passage and not a painting.
    float t = GameTime * 6283.185;
    p.x += sin(p.y * 23.0 + t * 1.3) * 0.004;
    p.y += sin(p.x * 19.0 - t * 1.1) * 0.004;
    vec3 color = panorama(normalize(p), rows);
    color = mix(color, color * vec3(0.86, 0.80, 1.0), 0.35);
    // Sampler0 read too: the pipeline binds it, a program that drops it is warned about.
    color += textureProj(Sampler0, texProj0).rgb * COLORS[0] * 0.5;
    for (int i = 10; i < PORTAL_LAYERS; i++) {
        color += stars(float(i + 1)) * COLORS[i] * 0.55;
    }
#else
    vec3 color = textureProj(Sampler0, texProj0).rgb * COLORS[0];
    for (int i = 0; i < PORTAL_LAYERS; i++) {
        color += stars(float(i + 1)) * COLORS[i];
    }
#endif
    fragColor = apply_fog(vec4(color, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
