#version 330

// Written by .claude/scripts/gen-portal-panorama.py: never hand-edit, rerun.
// Vanilla's, the faces hidden near the eye (item.vsh: within 1.50 blocks), and
// the rune portals' views: a face whose texel (level 0) is
// magenta with an alpha of 7 is the top left texel of a view's sprite (a
// panorama, 4 x 1.5 faces, its face size in the next texel); the sprite is found in the atlas from
// that texel and sampled along the eye's direction turned into its frame.
// 26.3 (not SB_MOJ): its own steps on top, the overlay, the lightmap and the glint in the
// fragment, and the OIT phases of a translucent item, which never is a view (opaque): there the
// view's code is left out, and with it Globals (the item's OIT pipeline binds it through its
// phase's snippet, its plain one through MATRICES_FOG; the view's haze reads GameTime).

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#else
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#if defined(GLINT) || !defined(OIT)
#include <minecraft:globals.glsl>
#endif
#endif

uniform sampler2D Sampler0;
#if defined(GLINT) && !defined(SB_MOJ)
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
SB_LOC(0) in float sphericalVertexDistance;
SB_LOC(1) in float cylindricalVertexDistance;
#endif
SB_LOC(2) in vec4 vertexColor;
#if !defined(OIT_ALPHA_ONLY) && !defined(SB_MOJ)
SB_LOC(3) in vec4 lightMapColor;
SB_LOC(4) in vec4 overlayColor;
#endif
SB_LOC(5) in vec2 texCoord0;
#if defined(GLINT) && !defined(SB_MOJ)
SB_LOC(6) in vec2 texCoordGlint;
#endif
SB_LOC(7) in vec3 portalEye;
SB_LOC(8) in vec2 portalFace;
SB_LOC(9) flat in int portalView;
SB_LOC(10) flat in int nearHidden;

#ifndef OIT_ALPHA_ONLY
SB_LOC(0) out vec4 fragColor;
#endif

// The eye's direction into a panorama's frame (its north: where one faces on
// arrival), by which way it looks through the disc: across x (the island's
// portal) from the east or the west, across z (the hub's, the realms') from
// the north or the south. n: the face's normal, any sign.
vec3 portal_frame(vec3 d, vec3 n) {
    if (n.x >= n.z) {
        return d.x < 0.0 ? vec3(-d.z, d.y, d.x) : vec3(d.z, d.y, -d.x);
    }
    return d.z > 0.0 ? vec3(-d.x, d.y, -d.z) : d;
}

// Where along p a panorama's block is read, in faces: the face's place (x, y)
// plus (u, v) times its size (sides 1, sky and ground 0.5), and that size.
vec3 portal_cube(vec3 p) {
    vec3 a = abs(p);
    vec3 fwd; vec3 right; vec3 up; vec3 rect;
    if (a.x >= a.y && a.x >= a.z) {
        if (p.x > 0.0) { fwd = vec3(1, 0, 0); right = vec3(0, 0, 1); up = vec3(0, 1, 0); rect = vec3(0.0, 0.0, 1.0); }
        else { fwd = vec3(-1, 0, 0); right = vec3(0, 0, -1); up = vec3(0, 1, 0); rect = vec3(1.0, 0.0, 1.0); }
    } else if (a.y >= a.z) {
        if (p.y > 0.0) { fwd = vec3(0, 1, 0); right = vec3(1, 0, 0); up = vec3(0, 0, -1); rect = vec3(0.0, 1.0, 0.5); }
        else { fwd = vec3(0, -1, 0); right = vec3(1, 0, 0); up = vec3(0, 0, 1); rect = vec3(0.5, 1.0, 0.5); }
    } else {
        if (p.z > 0.0) { fwd = vec3(0, 0, 1); right = vec3(-1, 0, 0); up = vec3(0, 1, 0); rect = vec3(2.0, 0.0, 1.0); }
        else { fwd = vec3(0, 0, -1); right = vec3(1, 0, 0); up = vec3(0, 1, 0); rect = vec3(3.0, 0.0, 1.0); }
    }
    vec3 q = p / dot(p, fwd);
    vec2 uv = vec2((dot(q, right) + 1.0) * 0.5, (1.0 - dot(q, up)) * 0.5);
    return vec3(rect.xy + uv * rect.z, rect.z);
}

#ifndef OIT_ALPHA_ONLY
// The colour's last steps: 26.3's (overlay, lightmap, glint, OIT accumulation) then the fog.
vec4 finalColor(vec4 color) {
#ifndef SB_MOJ
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;
#ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
#endif
#endif
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
#ifndef OIT
    // A view's derivatives, taken first, out of any branch or discard (else undefined).
    vec3 wx = dFdx(portalEye);
    vec3 wy = dFdy(portalEye);
    vec2 fx = dFdx(portalFace);
    vec2 fy = dFdy(portalFace);
    vec4 probe = portalView == 1 ? textureLod(Sampler0, texCoord0, 0.0) : vec4(0.0);
    if (portalView == 1 && probe.r > 0.99 && probe.g < 0.01 && probe.b > 0.99 && abs(probe.a * 255.0 - 7.0) < 0.5) {
        vec2 atlas = vec2(textureSize(Sampler0, 0));
        vec2 origin = floor(texCoord0 * atlas);
        // The view's face size: its block is 4 faces wide; its sprite's width is read from the
        // texel right of the magic one (its red and green: the face's texels / 256 and mod 256).
        vec4 size = textureLod(Sampler0, (origin + vec2(1.5, 0.5)) / atlas, 0.0);
        float viewFace = floor(size.r * 255.0 + 0.5) * 256.0 + floor(size.g * 255.0 + 0.5);
        // Where on its face (blocks from its middle at full size, y up): round, cut at the floor,
        // under the stones.
        vec2 q = portalFace * 5.70;
        if (dot(q, q) > 32.4900 || q.y < -5.50) {
            discard;
        }
        // The lens: the face's axes in the world (both the eye's vector and the face's place are
        // linear across it), its middle, and an eye drawn in to 8.0 blocks of it (at the portal's
        // size): from afar the view shows the place, not a crop of it.
        vec3 dir = normalize(portalEye);
        float det = fx.x * fy.y - fx.y * fy.x;
        if (abs(det) > 1e-9) {
            vec3 eu = (wx * fy.y - wy * fx.y) / det;
            vec3 ev = (wy * fx.x - wx * fy.x) / det;
            vec3 middle = portalEye - eu * portalFace.x - ev * portalFace.y;
            float lens = 8.0 * length(eu) / 5.70;
            float away = length(middle);
            vec3 eye = away > lens ? middle * (1.0 - lens / away) : vec3(0.0);
            dir = normalize(portalEye - eye);
        }
        vec3 n = abs(cross(wx, wy));
        vec3 p = portal_frame(dir, n);
        float t = GameTime * 6283.185;
        p.x += sin(p.y * 23.0 + t * 1.3) * 0.004;
        p.y += sin(p.x * 19.0 - t * 1.1) * 0.004;
        vec3 c = portal_cube(normalize(p));
        vec2 inside = fract(c.xy / c.z);
        vec2 base = floor(c.xy / c.z) * c.z;
        float margin = 2.5 / (viewFace * c.z);
        vec2 at = base + clamp(inside, margin, 1.0 - margin) * c.z;
        vec3 view = textureLod(Sampler0, (origin + at * viewFace) / atlas, 0.0).rgb;
        view = mix(view, view * vec3(0.86, 0.80, 1.0), 0.35);
        fragColor = apply_fog(vec4(view, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
        return;
    }
#endif
    // The eye's distance (the fog's spherical one, which an OIT alpha phase does not carry).
    if (nearHidden == 1 && length(portalEye) < 1.50) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= vertexColor * ColorModulator;
#if defined(GLINT) && !defined(SB_MOJ)
    color.a = max(color.a, GlintAlpha);
#endif
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
    fragColor = finalColor(color);
#endif
}
