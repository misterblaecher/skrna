#version 330

// The island border as a veil of aurora (Luka, 28/09; docs/features/island-border.md):
// a curtain glowing from under the island to well above it, its top edge
// wandering, rays drifting along it, pleats every two blocks, stars
// twinkling in it. Blended additively (the pipeline's OVERLAY is SRC_ALPHA,
// ONE): light, never a wall of stripes.
//
// Its colours follow the colour the island's co-owners chose, the only
// thing the client tells this shader (it tints the border by its motion,
// IslandBorderListener): blue, the default, is the Aether's periwinkle to
// lilac to rose; green is mint to sky; red is rose to peach to lilac. They
// are saturated here: added onto a pale sky they come out pastel. The
// vanilla alpha (ColorModulator.a) still fades it with distance.
// ONE SOURCE FOR THE THREE CLIENTS: 26.1 and 26.2 load rendertype_world_border, 26.3 the same
// file under its new name world_border (WorldBorderShaderTest keeps the two byte for byte).
// SB_MOJ is 26.1/26.2 (#moj_import, OpenGL), else 26.3 (Vulkan GLSL: #include, locations, the
// OIT phases of its OIT_ADDITIVE pipeline); see the BetterHud text template's head for the switch.

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:dynamictransforms.glsl>
#else
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#endif

uniform sampler2D Sampler0;

SB_LOC(0) in vec2 texCoord0;
SB_LOC(1) in vec2 borderPos;
SB_LOC(2) in float phase;

#ifndef OIT_ALPHA_ONLY
SB_LOC(0) out vec4 fragColor;
#endif

const float TAU = 6.2831853;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// Bottom (k = 0) to top (k = 1) of the curtain, in the chosen colour's family.
vec3 palette(vec3 tint, float k) {
    vec3 low;
    vec3 mid;
    vec3 high;
    if (tint.r > tint.g && tint.r > tint.b) {
        low = vec3(1.00, 0.30, 0.55);
        mid = vec3(1.00, 0.55, 0.30);
        high = vec3(0.65, 0.40, 1.00);
    } else if (tint.g > tint.b) {
        low = vec3(0.25, 1.00, 0.65);
        mid = vec3(0.20, 0.75, 1.00);
        high = vec3(0.55, 1.00, 0.85);
    } else {
        low = vec3(0.35, 0.50, 1.00);
        mid = vec3(0.65, 0.35, 1.00);
        high = vec3(1.00, 0.40, 0.75);
    }
    return k < 0.5 ? mix(low, mid, k * 2.0) : mix(mid, high, k * 2.0 - 1.0);
}

void main() {
    // Never true: it keeps Sampler0 in use, as the pipeline binds it.
    if (texture(Sampler0, texCoord0).a < 0.0) {
        discard;
    }
    float a = borderPos.x;
    float y = borderPos.y;
    // Every wave turns a whole number of times per loop: the 3 s clock never jumps.
    float t = phase * TAU;

    // The curtain: from under the island (its keel ~ y 48) to a top edge that wanders.
    float top = 100.0 + 7.0 * sin(a * 0.21 + t) + 4.0 * sin(a * 0.53 - 2.0 * t);
    float body = smoothstep(36.0, 56.0, y) * (1.0 - smoothstep(top - 30.0, top, y));

    // Rays drifting along it, brightening in slow bands going up.
    float rays = 0.55 + 0.25 * sin(a * 1.7 + t) + 0.2 * sin(a * 0.63 - t + 2.0 * sin(a * 0.21));
    rays *= 0.8 + 0.2 * sin(y * 0.35 - 2.0 * t + a * 0.4);
    // Fine pleats, one every two blocks.
    float pleat = pow(abs(sin(a * 1.5707963)), 12.0) * 0.35;
    // A faint veil at every height: a player building far above the curtain
    // still sees the line the client will not let them cross.
    // The hem: a bright band waving along the curtain's foot, as an aurora's.
    float hemY = 60.0 + 4.0 * sin(a * 0.3 + t) + 2.0 * sin(a * 0.9 - 2.0 * t);
    float hem = exp(-pow((y - hemY) / 5.0, 2.0)) * (0.7 + 0.3 * sin(a * 1.1 - t));
    float glow = body * (rays + pleat) + 0.12 * (rays + pleat) + hem;

    // Stars: one cell in six per block holds one, lit once a loop at its own moment.
    vec2 cell = floor(vec2(a, y));
    float star = 0.0;
    if (hash(cell) > 0.83) {
        float twinkle = max(sin(TAU * (phase + hash(cell + 7.3))), 0.0);
        vec2 f = fract(vec2(a, y)) - 0.5;
        star = (1.0 - smoothstep(0.0, 0.14, length(f))) * twinkle * smoothstep(40.0, 60.0, y)
                * (1.0 - smoothstep(top - 10.0, top + 10.0, y));
    }

    float alpha = ColorModulator.a * clamp(glow * 0.3 + star * 0.9, 0.0, 1.0);
    if (alpha < 0.003) {
        discard;
    }
    float k = clamp((y - 45.0) / (top - 45.0), 0.0, 1.0);
    vec3 colour = mix(palette(ColorModulator.rgb, k), vec3(1.0), star * 0.8);
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, alpha);
#elif defined(OIT_ACCUMULATE)
    fragColor = sampleColorForAccumulation(vec4(colour, alpha));
#else
    fragColor = vec4(colour, alpha);
#endif
}
