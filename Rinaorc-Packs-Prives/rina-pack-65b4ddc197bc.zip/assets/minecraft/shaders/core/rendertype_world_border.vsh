#version 330

// The island border as a veil of aurora (docs/features/island-border.md).
// Read off the 26.1.2 client (WorldBorderRenderer): Position.y is the WORLD
// height (ModelOffset.y is minus the camera's), Position.x and .z run from
// the border's corner (its min x, min z while the border is smaller than the
// view, as an island's is), so they hold still when the player moves.
// TextureMat's translation is the vanilla scroll, millis % 3000 / 3000: the
// only clock this pipeline gets (it binds no Globals, no Fog).
// ONE SOURCE FOR THE THREE CLIENTS: 26.1 and 26.2 load rendertype_world_border, 26.3 the same
// file under its new name world_border (WorldBorderShaderTest keeps the two byte for byte).
// SB_MOJ is 26.1/26.2 (#moj_import, OpenGL), else 26.3 (Vulkan GLSL: #include, locations, the
// OIT phases of its OIT_ADDITIVE pipeline); see the BetterHud text template's head for the switch.

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#else
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#endif

SB_LOC(0) in vec3 Position;
SB_LOC(1) in vec2 UV0;

SB_LOC(0) out vec2 texCoord0;
// x: blocks along the border, y: world height.
SB_LOC(1) out vec2 borderPos;
// 0 to 1 over three seconds, looping.
SB_LOC(2) out float phase;

void main() {
    vec3 pos = Position + ModelOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    borderPos = vec2(Position.x + Position.z, Position.y);
    phase = TextureMat[3][0];
}
