#version 330

// Written by .claude/scripts/gen-portal-panorama.py: never hand-edit, rerun.
// Vanilla's (26.1 and 26.2 under SB_MOJ; 26.3's otherwise: lightmap and overlay apart, the OIT
// phases, the glint), plus the vector from the eye to the vertex in world axes, for the rune
// portals' views (item.fsh), and the faces hidden near the eye. Outputs 0-6 are 26.3's, 7-10 ours.

#ifdef VULKAN
#extension GL_ARB_separate_shader_objects : require
#define SB_LOC(n) layout(location = n)
#else
#define SB_LOC(n)
#endif

/*
#moj_import <minecraft:rinaskyblock_moj_import.glsl>
*/
#if defined(RINASKYBLOCK_MOJ_IMPORT) || !defined(VULKAN)
#define SB_MOJ
#endif

#ifdef SB_MOJ
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#else
#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

SB_LOC(0) in vec3 Position;
SB_LOC(1) in vec4 Color;
SB_LOC(2) in vec2 UV0;
SB_LOC(3) in ivec2 UV1;
SB_LOC(4) in ivec2 UV2;
#if defined(GLINT_SPECIAL) && !defined(SB_MOJ)
SB_LOC(5) in vec2 UV3;
#endif
SB_LOC(6) in vec3 Normal;

uniform sampler2D Sampler0;
#ifndef OIT_ALPHA_ONLY
#ifndef SB_MOJ
uniform sampler2D Sampler1;
#endif
uniform sampler2D Sampler2;

SB_LOC(0) out float sphericalVertexDistance;
SB_LOC(1) out float cylindricalVertexDistance;
#endif
SB_LOC(2) out vec4 vertexColor;
#if !defined(OIT_ALPHA_ONLY) && !defined(SB_MOJ)
SB_LOC(3) out vec4 lightMapColor;
SB_LOC(4) out vec4 overlayColor;
#endif
SB_LOC(5) out vec2 texCoord0;
#if defined(GLINT) && !defined(SB_MOJ)
SB_LOC(6) out vec2 texCoordGlint;
#endif
SB_LOC(7) out vec3 portalEye;
SB_LOC(8) out vec2 portalFace;
SB_LOC(9) flat out int portalView;
SB_LOC(10) flat out int nearHidden;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif
#ifdef SB_MOJ
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif
#ifdef GLINT
#ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
#else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
#endif
#endif

    texCoord0 = UV0;
    portalEye = Position;
    // A rune portal's view is tinted (254, 1, 254): only its faces pay for the view's texel probe.
    portalView = Color.g < 0.02 && Color.r > 0.98 && Color.b > 0.98 ? 1 : 0;
    // Where on the view's face, -1..1 (y up): its corners sample the magic texel at 0.3 or 0.7.
    vec2 texel = portalView == 1 ? fract(UV0 * vec2(textureSize(Sampler0, 0))) : vec2(0.5);
    portalFace = vec2(texel.x < 0.5 ? -1.0 : 1.0, texel.y < 0.5 ? 1.0 : -1.0);
    // A face tinted (253, 255, 253) is hidden near the eye (item.fsh): a boss set's pauldrons
    // and the parts of its aura round the body, riding their wearer, would fill a first-person
    // view; from F5 or for anyone else they stand farther and show.
    nearHidden = abs(Color.r - 253.0 / 255.0) < 0.002 && Color.g > 0.998 && abs(Color.b - 253.0 / 255.0) < 0.002 ? 1 : 0;
}
