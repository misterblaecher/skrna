// RinaSkyblock: "GUI text has pipelines of its own" for the text shader (BetterHud's template,
// docs/features/client-versions.md "Compile cost"). Empty here, at the pack's root: 26.1 (format 84)
// draws GUI text with its one text program, which must keep our shows. The plugin's pack module
// (pack/GuiPipelineOverlay) adds a copy defining SB_GUI_PIPELINE in an overlay of formats 88+: 26.2 and
// 26.3 draw GUI text with IS_GUI, so their world variants leave our shows out.
